"""
Step 08: Frontend Code Generator
Generates React services, hooks, and wires the TSX component.
NO HARDCODING - reads all configuration from wired_ui.json.

Usage:
    python step_08_frontend_generator_gemini_llm_rewrite_v5.py <wired_ui.json> <input_tsx> <input_dir> <output_dir>

Example:
    python step_08_frontend_generator_gemini_llm_rewrite_v5.py wired_ui.json ui_react_component.tsx . ./output
"""

import json
import re
from pathlib import Path
import sys
from typing import Dict, Any, List, Optional, Tuple


class FrontendCodeGenerator:
    """
    Generates frontend code based on wiring plan.
    All configuration comes from wired_ui.json - no hardcoding.
    """
    
    def __init__(
        self,
        wiring_plan: Dict[str, Any],
        input_dir: Path,
        output_dir: Path,
        tsx_metadata_path: Optional[Path] = None
    ):
        self.wiring = wiring_plan
        self.input_dir = input_dir
        self.output_dir = output_dir
        self.tsx_metadata_path = tsx_metadata_path
        self.tsx_metadata = None
        
        # Load tsx_metadata if provided
        if tsx_metadata_path and tsx_metadata_path.exists():
            try:
                with open(tsx_metadata_path, 'r', encoding='utf-8') as f:
                    self.tsx_metadata = json.load(f)
                print(f"[INFO] Loaded TSX metadata: {tsx_metadata_path}")
            except Exception as e:
                print(f"[WARNING] Failed to load TSX metadata: {e}")
                self.tsx_metadata = None
        
        # Extract key info from wiring plan
        self.app_name = self.wiring.get('metadata', {}).get('app_name', 'App')
        self.entity_services = self.wiring.get('entity_services', [])
        self.screen_mappings = self.wiring.get('screen_mappings', [])
        self.mock_data_removal = self.wiring.get('mock_data_removal', [])
        
        # Derive names from config (no hardcoding)
        self.app_name_normalized = self._normalize_name(self.app_name)
        self.output_tsx_name = f"{self.app_name_normalized}_WIRED.tsx"
        
        # Setup directories
        self.src_dir = self.output_dir / "src"
        self.services_dir = self.src_dir / "services"
        self.hooks_dir = self.src_dir / "hooks"
        self.types_dir = self.src_dir / "types"
        self.schemas_dir = self.src_dir / "schemas"
        self.components_dir = self.src_dir / "components"
        self.screens_dir = self.src_dir / "screens"
        self.forms_dir = self.src_dir / "forms"
        self.styles_dir = self.src_dir / "styles"
        
        for d in [self.output_dir, self.output_dir / "public", 
                  self.src_dir, self.services_dir, self.hooks_dir, self.types_dir, 
                  self.schemas_dir, self.components_dir, self.screens_dir, 
                  self.forms_dir, self.styles_dir]:
            d.mkdir(parents=True, exist_ok=True)
    
    def generate(self):
        """Main generation method."""
        print(f"\n{'='*60}")
        print(f"--- Step 08: Frontend Code Generation (No Hardcoding) ---")
        print(f"{'='*60}")
        print(f"App Name: {self.app_name}")
        print(f"Output TSX: {self.output_tsx_name}")
        
        # 1. Generate type definitions
        self._generate_types()
        
        # 2. Generate services
        self._generate_services()
        
        # 3. Generate Zod schemas
        self._generate_schemas()
        
        # 4. Generate hooks with validations
        self._generate_hooks()
        
        # 5. Generate reusable UI components
        self._generate_ui_components()
        
        # 6. Generate screen-level components
        self._generate_screen_components()
        
        # 7. Generate infrastructure
        self._generate_infrastructure()
        
        # 8. Process and wire TSX with enterprise architecture
        self._process_tsx()
        
        print(f"\n[SUCCESS] Generation complete!")
        print(f"Output directory: {self.output_dir}")
    
    def _normalize_name(self, name: str) -> str:
        """Convert name to PascalCase."""
        return ''.join(
            word.capitalize() 
            for word in re.split(r'[^a-zA-Z0-9]+', name) 
            if word
        )
    
    def _generate_form_name_from_screen(self, tsx_screen_name: str, story_id: str = '') -> str:
        """Generate standard form name from screen name.
        
        Priority:
        1. Use screen name (e.g., 'WorklistScreen' -> 'WorklistForm')
        2. Fallback to story-based naming if screen name not available
        """
        if tsx_screen_name and tsx_screen_name != 'UnknownScreen':
            # Remove 'Screen' suffix if present, add 'Form' suffix
            screen_base = tsx_screen_name.replace('Screen', '').replace('screen', '')
            if screen_base:
                return f"{screen_base}Form"
        
        # Fallback to story-based naming
        if story_id:
            normalized = self._normalize_name(story_id.replace(' ', ''))
            # Clean up common prefixes like 'User', 'Story'
            normalized = re.sub(r'^(User|Story)', '', normalized)
            return f"{normalized}Form" if normalized else "Form"
        
        return "Form"
    
    def _generate_hook_name_from_screen(self, tsx_screen_name: str, story_id: str = '') -> str:
        """Generate standard hook name from screen name.
        
        Returns: camelCase hook name (e.g., 'useWorklistForm')
        """
        form_name = self._generate_form_name_from_screen(tsx_screen_name, story_id)
        # Convert PascalCase to camelCase and add 'use' prefix
        # Example: WorklistForm -> useWorklistForm (capitalize first letter after 'use')
        if form_name:
            # Remove 'Form' suffix if present, keep the base name
            base_name = form_name.replace('Form', '') if form_name.endswith('Form') else form_name
            # Return: use + PascalCase base (e.g., useWorklist)
            return f"use{base_name}"
        return "useForm"
    
    def _generate_schema_name_from_screen(self, tsx_screen_name: str, story_id: str = '') -> str:
        """Generate standard schema name from screen name.
        
        Returns: PascalCase schema name (e.g., 'WorklistFormSchema')
        """
        form_name = self._generate_form_name_from_screen(tsx_screen_name, story_id)
        return f"{form_name}Schema" if form_name else "FormSchema"
    
    def _generate_screen_form_type_name(self, story_id: str) -> str:
        """Generate type name for screen-specific FormData."""
        return f"{self._normalize_name(story_id.replace(' ', ''))}FormData"
    
    def _generate_screen_form_type(self, story_id: str, field_mappings: List[Dict]) -> str:
        """Generate TypeScript interface for screen-specific form data."""
        type_name = self._generate_screen_form_type_name(story_id)
        fields = []
        
        for mapping in field_mappings:
            binding = mapping.get('config_binding', '')
            field_id = self._extract_column_from_binding(binding)
            if not field_id:
                field_id = mapping.get('config_field_id', '')
            
            if field_id:
                # Infer type from validations
                field_type = self._infer_field_type(mapping)
                fields.append(f"  {field_id}?: {field_type};")
        
        if not fields:
            return f"interface {type_name} {{\n  [key: string]: any;\n}}"
        
        return f"interface {type_name} {{\n" + "\n".join(fields) + "\n}"
    
    def _infer_field_type(self, mapping: Dict) -> str:
        """Infer TypeScript type from field mapping."""
        validations = mapping.get('validations', [])
        for validation in validations:
            rule = validation.get('rule', '').lower()
            if 'number' in rule or 'integer' in rule or 'positive' in rule:
                return 'number'
            if 'boolean' in rule:
                return 'boolean'
        return 'string'
    
    def _to_camel_case(self, name: str) -> str:
        """Convert name to camelCase."""
        pascal = self._normalize_name(name)
        if pascal:
            return pascal[0].lower() + pascal[1:]
        return ''
    
    def _extract_column_from_binding(self, binding: str) -> str:
        """
        Extract column name from binding string for data operations.
        
        This ensures formData properties match actual database columns,
        supporting multi-language UI labels while maintaining correct data layer.
        
        Args:
            binding: Binding string in format 'table.column' or 'column'
            
        Returns:
            Column name to use for formData properties
            
        Examples:
            >>> self._extract_column_from_binding('nsi_items.disposition')
            'disposition'
            >>> self._extract_column_from_binding('inventory.item_id')
            'item_id'
            >>> self._extract_column_from_binding('status')
            'status'
        """
        if not binding:
            return ''
        
        # Handle 'table.column' format
        if '.' in binding:
            parts = binding.rsplit('.', 1)
            return parts[1] if len(parts) == 2 else binding
        
        # Handle plain 'column' format
        return binding
    
    def _generate_types(self):
        """Generate TypeScript type definitions from entity schemas."""
        print("\n[1] Generating type definitions...")
        
        types_content = [
            "// Auto-generated type definitions",
            "// DO NOT EDIT - Generated by step_08_frontend_generator",
            ""
        ]
        
        for service in self.entity_services:
            entity_name = service['entity_name']
            class_name = self._normalize_name(entity_name)
            fields = service.get('fields', [])
            pk = service.get('primary_key', 'id')
            pk_type = self._map_to_ts_type(service.get('primary_key_type', 'int'))
            
            # Generate interface
            types_content.append(f"export interface {class_name} {{")
            
            for field in fields:
                field_name = field['name']
                ts_type = field.get('typescript_type', 'any')
                nullable = field.get('nullable', True)
                
                optional = '?' if nullable or field_name == pk else ''
                types_content.append(f"  {field_name}{optional}: {ts_type};")
            
            types_content.append("}")
            types_content.append("")
            
            # Generate Create DTO (exclude auto-generated fields)
            types_content.append(f"export interface {class_name}Create {{")
            for field in fields:
                if field.get('auto_increment') or field.get('primary_key'):
                    continue
                if field.get('default') and field['name'] in ['created_date', 'modified_date']:
                    continue
                
                field_name = field['name']
                ts_type = field.get('typescript_type', 'any')
                nullable = field.get('nullable', True)
                has_default = field.get('default') is not None
                
                optional = '?' if nullable or has_default else ''
                types_content.append(f"  {field_name}{optional}: {ts_type};")
            
            types_content.append("}")
            types_content.append("")
        
        # Write types file
        types_file = self.types_dir / "entities.ts"
        types_file.write_text('\n'.join(types_content), encoding='utf-8')
        print(f"  ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ Generated {types_file.name}")
    
    def _map_to_ts_type(self, type_str: str) -> str:
        """Map type string to TypeScript type."""
        type_map = {
            'int': 'number',
            'str': 'string',
            'float': 'number',
            'bool': 'boolean',
            'datetime': 'string',
            'date': 'string',
            'UUID': 'string',
            'Decimal': 'number',
        }
        return type_map.get(type_str, 'any')
    
    def _generate_zod_schema_file(self, screen_mapping: Dict[str, Any]) -> Tuple[str, str]:
        """Generate Zod schema file for a screen."""
        story_id = screen_mapping.get('story_id', '')
        tsx_screen_name = screen_mapping.get('tsx_screen_name', 'UnknownScreen')
        field_mappings = screen_mapping.get('field_mappings', [])
        
        # Use standard naming convention based on screen name
        schema_name = self._generate_schema_name_from_screen(tsx_screen_name, story_id)
        
        schema_lines = [
            "// Auto-generated Zod schema",
            "import { z } from 'zod';",
            ""
        ]
        
        schema_lines.append(f"export const {schema_name} = z.object({{")
        
        # Track processed fields to avoid duplicates
        processed_fields = set()
        
        for mapping in field_mappings:
            binding = mapping.get('config_binding', '')
            field_id = self._extract_column_from_binding(binding)
            
            if not field_id:
                field_id = mapping.get('config_field_id', '')
            
            if not field_id:
                continue
            
            # Skip if already processed
            if field_id in processed_fields:
                continue
            processed_fields.add(field_id)
            
            validations = mapping.get('validations', [])
            error_messages = mapping.get('error_messages', {})
            
            # Build Zod field schema
            zod_field = self._build_zod_field_schema(field_id, validations, error_messages)
            schema_lines.append(f"  {field_id}: {zod_field},")
        
        schema_lines.append("});")
        schema_lines.append("")
        schema_lines.append(f"export type {schema_name}Type = z.infer<typeof {schema_name}>;")
        
        return '\n'.join(schema_lines), schema_name
    
    def _build_zod_field_schema(
        self, 
        field_id: str, 
        validations: List[Dict], 
        error_messages: Dict[str, str]
    ) -> str:
        """Build Zod schema string for a single field."""
        if not validations:
            return "z.string().optional()"
        
        base_type = None
        is_required = False
        
        # Determine base type and required status from validations
        for validation in validations:
            rule = validation.get('rule', '').lower()
            is_required = is_required or validation.get('required', False) or 'required' in rule or 'must be present' in rule
            
            # Determine TypeScript/Zod type
            # Only set to number if explicitly integer/number AND not a format validation
            if ('integer' in rule or 'number' in rule) and 'format' not in rule and 'regex' not in rule and 'must be valid' not in rule:
                if 'positive' in rule:
                    base_type = 'number'
            elif 'boolean' in rule:
                base_type = 'boolean'
            else:
                # Default to string for text fields, tracking numbers, etc.
                if base_type is None:
                    base_type = 'string'
        
        if not base_type:
            base_type = 'string'
        
        # Build base Zod schema
        # IMPORTANT: Use z.coerce.number() for numeric fields when valueAsNumber is used
        # According to React Hook Form docs: valueAsNumber converts string to number
        # Zod needs coercion to handle this conversion properly
        if base_type == 'number':
            zod_schema = "z.coerce.number()"
        elif base_type == 'boolean':
            zod_schema = "z.boolean()"
        else:
            zod_schema = "z.string()"
        
        # Add validations in correct order: type validations FIRST, then refinements
        # For numbers: .int() and .positive() must come BEFORE .refine()
        required_added = False
        format_added = False
        int_added = False
        positive_added = False
        
        # First pass: Apply type-specific validations (int, positive) BEFORE refine
        if base_type == 'number':
            for validation in validations:
                rule = validation.get('rule', '').lower()
                default_error = validation.get('error_message', f'{field_id} is invalid')
                custom_error = error_messages.get(rule, error_messages.get('required', default_error))
                custom_error = custom_error.replace('"', '\\"')
                
                # Apply integer validation first
                if 'integer' in rule and not int_added:
                    zod_schema += f'.int({{ message: "{custom_error}" }})'
                    int_added = True
                
                # Apply positive validation (after int if both present)
                if 'positive' in rule and not positive_added:
                    zod_schema += f'.positive({{ message: "{custom_error}" }})'
                    positive_added = True
        
        # Second pass: Apply required validation and other refinements
        for validation in validations:
            rule = validation.get('rule', '').lower()
            default_error = validation.get('error_message', f'{field_id} is invalid')
            
            # Custom error message from config (prioritize)
            custom_error = error_messages.get(rule, error_messages.get('required', default_error))
            # Escape quotes in error messages
            custom_error = custom_error.replace('"', '\\"')
            
            # Required validation (only add once)
            if is_required and not required_added:
                if base_type == 'string':
                    zod_schema += f'.min(1, {{ message: "{custom_error}" }})'
                    required_added = True
                elif base_type == 'number':
                    # For numbers, use refine for required (after type validations)
                    zod_schema += f'.refine((val) => val !== null && val !== undefined, {{ message: "{custom_error}" }})'
                    required_added = True
            
            # Format validation (regex patterns) - only for strings, only add once
            if base_type == 'string' and not format_added and ('format' in rule or 'regex' in rule or 'must be valid' in rule or 'tracking number' in rule):
                pattern = self._extract_regex_pattern(rule)
                if pattern:
                    zod_schema += f'.regex({pattern}, {{ message: "{custom_error}" }})'
                    format_added = True
            
            # Custom business rule validations using .refine() (for string equality checks)
            if base_type == 'string' and 'must be' in rule and "'" in rule:
                # Example: "must be 'Salvage' to start workflow"
                expected_value = rule.split("'")[1] if "'" in rule else None
                if expected_value:
                    zod_schema += f'.refine((val) => val === "{expected_value}", {{ message: "{custom_error}" }})'
        
        # Make optional if not required
        if not is_required:
            zod_schema += '.optional()'
        
        return zod_schema
    
    def _extract_regex_pattern(self, rule: str) -> Optional[str]:
        """Extract regex pattern from validation rule."""
        # Common patterns
        patterns = {
            'tracking number': r'/^[A-Z0-9]{8,12}$/',
            'email': r'/^[^\s@]+@[^\s@]+\.[^\s@]+$/',
            'phone': r'/^\+?[\d\s-()]{10,}$/',
            'url': r'/^https?:\/\/.+/',
        }
        
        rule_lower = rule.lower()
        for key, pattern in patterns.items():
            if key in rule_lower:
                return pattern
        
        return None
    
    def _generate_schemas(self):
        """Generate Zod schema files for each screen."""
        print("\n[3] Generating Zod schemas...")
        
        for screen_mapping in self.screen_mappings:
            schema_content, schema_name = self._generate_zod_schema_file(screen_mapping)
            schema_file = self.schemas_dir / f"{schema_name}.ts"
            schema_file.write_text(schema_content, encoding='utf-8')
            print(f"  ✓ Generated {schema_name}.ts")
    
    def _generate_services(self):
        """Generate API service files for each entity."""
        print("\n[2] Generating services...")
        
        # Generate API client
        api_client_content = """// Auto-generated API client
import axios from 'axios';

const apiClient = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:8000',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for auth tokens
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('auth_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('API Error:', error.response?.data || error.message);
    return Promise.reject(error);
  }
);

export default apiClient;
"""
        (self.services_dir / 'apiClient.ts').write_text(api_client_content, encoding='utf-8')
        print(f"  ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ Generated apiClient.ts")
        
        # Generate service for each entity
        for service in self.entity_services:
            self._generate_entity_service(service)
    
    def _generate_entity_service(self, service: Dict[str, Any]):
        """Generate service file for a single entity."""
        entity_name = service['entity_name']
        service_name = service['service_name']
        class_name = self._normalize_name(entity_name)
        pk = service.get('primary_key', 'id')
        pk_type = self._map_to_ts_type(service.get('primary_key_type', 'int'))
        
        # Find APIs for this entity
        apis = service.get('apis', [])
        
        # Determine base endpoint from APIs or entity name
        base_endpoint = f"/api/v1/{entity_name}"
        for api in apis:
            endpoint = api.get('endpoint', '')
            if '/{' not in endpoint and endpoint:
                base_endpoint = endpoint.rstrip('/')
                break
        
        service_content = f"""// Auto-generated service for {entity_name}
import apiClient from './apiClient';
import {{ {class_name}, {class_name}Create }} from '../types/entities';

export interface ApiResponse<T> {{
  data: T;
  message?: string;
}}

export interface PaginatedResponse<T> {{
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}}

const {service_name} = {{
  /**
   * Get all {entity_name} records
   */
  getAll: async (): Promise<{class_name}[]> => {{
    const response = await apiClient.get('{base_endpoint}/');
    return response.data;
  }},

  /**
   * Get a single {entity_name} by {pk}
   */
  getById: async ({pk}: {pk_type}): Promise<{class_name}> => {{
    const response = await apiClient.get(`{base_endpoint}/${{{pk}}}`);
    return response.data;
  }},

  /**
   * Create a new {entity_name}
   */
  create: async (data: {class_name}Create): Promise<{class_name}> => {{
    const response = await apiClient.post('{base_endpoint}/', data);
    return response.data;
  }},

  /**
   * Update an existing {entity_name}
   */
  update: async ({pk}: {pk_type}, data: Partial<{class_name}>): Promise<{class_name}> => {{
    const response = await apiClient.put(`{base_endpoint}/${{{pk}}}`, data);
    return response.data;
  }},

  /**
   * Delete a {entity_name}
   */
  delete: async ({pk}: {pk_type}): Promise<boolean> => {{
    await apiClient.delete(`{base_endpoint}/${{{pk}}}`);
    return true;
  }},
}};

export default {service_name};
"""
        
        service_file = self.services_dir / f"{service_name}.ts"
        service_file.write_text(service_content, encoding='utf-8')
        print(f"  ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ Generated {service_name}.ts")
    
    def _generate_hooks(self):
        """Generate React hooks for each screen with validations."""
        print("\n[3] Generating hooks...")
        
        for screen_mapping in self.screen_mappings:
            self._generate_screen_hook(screen_mapping)
    
    def _generate_screen_hook(self, screen_mapping: Dict[str, Any]):
        """Generate hook for a single screen using React Hook Form + Zod."""
        story_id = screen_mapping.get('story_id', '')
        tsx_screen_name = screen_mapping.get('tsx_screen_name', 'UnknownScreen')
        primary_entity = screen_mapping.get('primary_entity', '')
        field_mappings = screen_mapping.get('field_mappings', [])
        handler_mappings = screen_mapping.get('handler_mappings', [])
        
        # Use standard naming conventions based on screen name
        hook_name = self._generate_hook_name_from_screen(tsx_screen_name, story_id)
        entity_class = self._normalize_name(primary_entity)
        service_name = f"{entity_class}Service"
        schema_name = self._generate_schema_name_from_screen(tsx_screen_name, story_id)
        
        # Generate handler code
        form_type_name = f"{schema_name}Type"
        handler_code = self._build_handler_code(handler_mappings, service_name, entity_class, form_type_name, field_mappings)
        
        hook_content = f"""// Auto-generated hook for {story_id}
// Screen: {tsx_screen_name}
// Uses React Hook Form + Zod for validation
import {{ useState, useCallback }} from 'react';
import {{ useForm }} from 'react-hook-form';
import {{ zodResolver }} from '@hookform/resolvers/zod';
import {{ {schema_name}, {schema_name}Type }} from '../schemas/{schema_name}';
import {service_name} from '../services/{service_name}';
import {{ {entity_class}, {entity_class}Create }} from '../types/entities';

interface UseLogicResult {{
  loading: boolean;
  register: ReturnType<typeof useForm<{schema_name}Type>>['register'];
  handleSubmit: ReturnType<typeof useForm<{schema_name}Type>>['handleSubmit'];
  watch: ReturnType<typeof useForm<{schema_name}Type>>['watch'];
  errors: ReturnType<typeof useForm<{schema_name}Type>>['formState']['errors'];
  setError: ReturnType<typeof useForm<{schema_name}Type>>['setError'];
  clearErrors: ReturnType<typeof useForm<{schema_name}Type>>['clearErrors'];
  reset: ReturnType<typeof useForm<{schema_name}Type>>['reset'];
  {self._build_handler_type_signatures(handler_mappings)}
}}

export const {hook_name} = (
  showNotification: (message: string, type: 'success' | 'danger' | 'warning') => void
): UseLogicResult => {{
  const [loading, setLoading] = useState(false);

  // Calculate default values for form
  const getDefaultValues = (): Partial<{schema_name}Type> => {{
    return {self._generate_default_values(field_mappings)};
  }};

  const {{
    register,
    handleSubmit: hookFormHandleSubmit,
    formState: {{ errors }},
    setError,
    clearErrors,
    reset,
    watch
  }} = useForm<{schema_name}Type>({{
    resolver: zodResolver({schema_name}),
    mode: 'onBlur', // Validate on blur - shows errors when user leaves field
    reValidateMode: 'onChange', // Re-validate on change after initial error
    criteriaMode: 'all', // Show all validation errors, not just the first one
    defaultValues: getDefaultValues(), // Use defaultValues instead of useState
    shouldFocusError: true // Focus first error field after validation fails
  }});

  {handler_code}

  return {{
    loading,
    register,
    handleSubmit: hookFormHandleSubmit,
    watch,
    errors,
    setError,
    clearErrors,
    reset,
    {self._build_handler_return_list(handler_mappings)}
  }};
}};

export default {hook_name};
"""
        
        # Use lowercase filename but keep camelCase export name
        hook_file_name_lower = hook_name[0].lower() + hook_name[1:]  # e.g., useWorklistForm -> useWorklistForm (same, but lowercase filename)
        hook_file = self.hooks_dir / f"{hook_file_name_lower}.ts"
        hook_file.write_text(hook_content, encoding='utf-8')
        print(f"  ✓ Generated {hook_file_name_lower}.ts (with React Hook Form + Zod)")
    
    def _generate_ui_components(self):
        """Generate reusable UI components following enterprise best practices."""
        print("\n[4] Generating reusable UI components...")
        
        self._generate_form_input_component()
        self._generate_form_select_component()
        self._generate_error_text_component()
        self._generate_modal_component()
        self._generate_notification_component()
        self._generate_css_file()
    
    def _generate_form_input_component(self):
        """Generate reusable FormInput component."""
        component_content = """// Reusable FormInput component
// Enterprise-ready: No inline styles, proper error handling
import React from 'react';
import { UseFormRegister, FieldError } from 'react-hook-form';
import { ErrorText } from '../ErrorText/ErrorText';

interface FormInputProps {
  id: string;
  label: string;
  type?: 'text' | 'number' | 'email' | 'password';
  register: UseFormRegister<any>;
  fieldName: string;
  error?: FieldError;
  placeholder?: string;
  valueAsNumber?: boolean;
  className?: string;
}

export const FormInput: React.FC<FormInputProps> = ({
  id,
  label,
  type = 'text',
  register,
  fieldName,
  error,
  placeholder,
  valueAsNumber = false,
  className = ''
}) => {
  const hasError = !!error;
  
  return (
    <div className={`form-field ${className}`}>
      <label htmlFor={id} className="form-label">
        {label}
      </label>
      <input
        id={id}
        type={type}
        {...register(fieldName, { valueAsNumber })}
        className={`form-input ${hasError ? 'form-input-error' : ''}`}
        placeholder={placeholder}
        aria-invalid={hasError}
        aria-describedby={hasError ? `${id}-error` : undefined}
      />
      {hasError && (
        <ErrorText id={`${id}-error`} message={error.message || 'Invalid value'} />
      )}
    </div>
  );
};

export default FormInput;
"""
        # Create subfolder for FormInput component
        form_input_dir = self.components_dir / "FormInput"
        form_input_dir.mkdir(parents=True, exist_ok=True)
        component_file = form_input_dir / "FormInput.tsx"
        component_file.write_text(component_content, encoding='utf-8')
        print("  ✓ Generated FormInput/FormInput.tsx")
    
    def _generate_form_select_component(self):
        """Generate reusable FormSelect component."""
        component_content = """// Reusable FormSelect component
// Enterprise-ready: Proper enum handling, no inline styles
import React from 'react';
import { UseFormRegister, FieldError } from 'react-hook-form';
import { ErrorText } from '../ErrorText/ErrorText';

interface FormSelectProps {
  id: string;
  label: string;
  register: UseFormRegister<any>;
  fieldName: string;
  error?: FieldError;
  options: Array<{ value: string; label: string }>;
  placeholder?: string;
  className?: string;
}

export const FormSelect: React.FC<FormSelectProps> = ({
  id,
  label,
  register,
  fieldName,
  error,
  options,
  placeholder,
  className = ''
}) => {
  const hasError = !!error;
  
  return (
    <div className={`form-field ${className}`}>
      <label htmlFor={id} className="form-label">
        {label}
      </label>
      <select
        id={id}
        {...register(fieldName)}
        className={`form-select ${hasError ? 'form-select-error' : ''}`}
        aria-invalid={hasError}
        aria-describedby={hasError ? `${id}-error` : undefined}
      >
        {placeholder && (
          <option value="">{placeholder}</option>
        )}
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {hasError && (
        <ErrorText id={`${id}-error`} message={error.message || 'Invalid value'} />
      )}
    </div>
  );
};

export default FormSelect;
"""
        # Create subfolder for FormSelect component
        form_select_dir = self.components_dir / "FormSelect"
        form_select_dir.mkdir(parents=True, exist_ok=True)
        component_file = form_select_dir / "FormSelect.tsx"
        component_file.write_text(component_content, encoding='utf-8')
        print("  ✓ Generated FormSelect/FormSelect.tsx")
    
    def _generate_error_text_component(self):
        """Generate reusable ErrorText component."""
        component_content = """// Reusable ErrorText component
// Enterprise-ready: Accessible, styled consistently
import React from 'react';

interface ErrorTextProps {
  id?: string;
  message: string;
  className?: string;
}

export const ErrorText: React.FC<ErrorTextProps> = ({
  id,
  message,
  className = ''
}) => {
  return (
    <span
      id={id}
      className={`error-text ${className}`}
      role="alert"
      aria-live="polite"
    >
      {message}
    </span>
  );
};

export default ErrorText;
"""
        # Create subfolder for ErrorText component
        error_text_dir = self.components_dir / "ErrorText"
        error_text_dir.mkdir(parents=True, exist_ok=True)
        component_file = error_text_dir / "ErrorText.tsx"
        component_file.write_text(component_content, encoding='utf-8')
        print("  ✓ Generated ErrorText/ErrorText.tsx")
    
    def _generate_modal_component(self):
        """Generate reusable Modal component."""
        component_content = """// Reusable Modal component
// Enterprise-ready: Proper React patterns, no dangerouslySetInnerHTML
import React, { ReactNode } from 'react';
import './Modal.css';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
  className?: string;
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  children,
  className = ''
}) => {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className={`modal-content ${className}`} onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          {title && <h2 className="modal-title">{title}</h2>}
          <button
            type="button"
            className="modal-close"
            onClick={onClose}
            aria-label="Close modal"
          >
            ×
          </button>
        </div>
        <div className="modal-body">
          {children}
        </div>
      </div>
    </div>
  );
};

export default Modal;
"""
        # Create subfolder for Modal component
        modal_dir = self.components_dir / "Modal"
        modal_dir.mkdir(parents=True, exist_ok=True)
        component_file = modal_dir / "Modal.tsx"
        component_file.write_text(component_content, encoding='utf-8')
        print("  ✓ Generated Modal/Modal.tsx")
        
        # Generate Modal CSS
        modal_css = """/* Modal component styles */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 8px;
  max-width: 90vw;
  max-height: 90vh;
  overflow: auto;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  border-bottom: 1px solid #e0e0e0;
}

.modal-title {
  margin: 0;
  font-size: 1.25rem;
  font-weight: 600;
}

.modal-close {
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  padding: 0;
  width: 2rem;
  height: 2rem;
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-close:hover {
  background: #f0f0f0;
  border-radius: 4px;
}

.modal-body {
  padding: 1rem;
}
"""
        css_file = modal_dir / "Modal.css"
        css_file.write_text(modal_css, encoding='utf-8')
    
    def _generate_notification_component(self):
        """Generate reusable Notification component."""
        component_content = """// Centralized Notification component
// Enterprise-ready: Single source of truth for notifications
import React, { useState, useCallback, useEffect } from 'react';
import './Notification.css';

export type NotificationType = 'success' | 'danger' | 'warning' | 'info';

interface Notification {
  id: string;
  message: string;
  type: NotificationType;
}

interface NotificationContextValue {
  showNotification: (message: string, type: NotificationType) => void;
}

export const NotificationContext = React.createContext<NotificationContextValue | null>(null);

export const useNotification = (): NotificationContextValue => {
  const context = React.useContext(NotificationContext);
  if (!context) {
    // Fallback: Create a default implementation when used outside provider
    console.warn('useNotification used outside NotificationProvider, using console fallback');
    return {
      showNotification: (message: string, type: NotificationType) => {
        console.log(`[${type.toUpperCase()}] ${message}`);
      }
    };
  }
  return context;
};

interface NotificationProviderProps {
  children: React.ReactNode;
}

export const NotificationProvider: React.FC<NotificationProviderProps> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const showNotification = useCallback((message: string, type: NotificationType) => {
    const id = Date.now().toString();
    setNotifications((prev) => [...prev, { id, message, type }]);

    // Auto-remove after 5 seconds
    setTimeout(() => {
      setNotifications((prev) => prev.filter((n) => n.id !== id));
    }, 5000);
  }, []);

  const removeNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  return (
    <NotificationContext.Provider value={{ showNotification }}>
      {children}
      <div className="notification-container">
        {notifications.map((notification) => (
          <div
            key={notification.id}
            className={`notification notification-${notification.type}`}
            role="alert"
          >
            <span className="notification-message">{notification.message}</span>
            <button
              type="button"
              className="notification-close"
              onClick={() => removeNotification(notification.id)}
              aria-label="Close notification"
            >
              ×
            </button>
          </div>
        ))}
      </div>
    </NotificationContext.Provider>
  );
};

export default NotificationProvider;
"""
        # Create subfolder for Notification component
        notification_dir = self.components_dir / "Notification"
        notification_dir.mkdir(parents=True, exist_ok=True)
        component_file = notification_dir / "Notification.tsx"
        component_file.write_text(component_content, encoding='utf-8')
        print("  ✓ Generated Notification/Notification.tsx")
        
        # Generate Notification CSS
        notification_css = """/* Notification component styles */
.notification-container {
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: 2000;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.notification {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem;
  border-radius: 4px;
  min-width: 300px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
  from {
    transform: translateX(100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}

.notification-success {
  background: #d4edda;
  color: #155724;
  border-left: 4px solid #28a745;
}

.notification-danger {
  background: #f8d7da;
  color: #721c24;
  border-left: 4px solid #dc3545;
}

.notification-warning {
  background: #fff3cd;
  color: #856404;
  border-left: 4px solid #ffc107;
}

.notification-info {
  background: #d1ecf1;
  color: #0c5460;
  border-left: 4px solid #17a2b8;
}

.notification-message {
  flex: 1;
}

.notification-close {
  background: none;
  border: none;
  font-size: 1.25rem;
  cursor: pointer;
  padding: 0;
  margin-left: 1rem;
  opacity: 0.7;
}

.notification-close:hover {
  opacity: 1;
}
"""
        css_file = notification_dir / "Notification.css"
        css_file.write_text(notification_css, encoding='utf-8')
    
    def _generate_css_file(self):
        """Generate main CSS file with form styles and theme."""
        css_content = """/* Enterprise-ready form styles and theme */
/* Centralized styling - no inline styles in components */

:root {
  --primary-color: #0D5DAB;
  --primary-hover: #0a4a8a;
  --error-color: #dc3545;
  --success-color: #28a745;
  --warning-color: #ffc107;
  --border-color: #ddd;
  --border-radius: 5px;
  --spacing-unit: 8px;
  --font-size-base: 1rem;
  --font-size-small: 0.875rem;
}

/* Form field styles */
.form-field {
  margin-bottom: calc(var(--spacing-unit) * 2);
}

.form-label {
  display: block;
  margin-bottom: calc(var(--spacing-unit) / 2);
  font-weight: 600;
  font-size: var(--font-size-base);
  color: #333;
}

.form-input,
.form-select {
  width: 100%;
  padding: calc(var(--spacing-unit) * 1.5);
  border: 1px solid var(--border-color);
  border-radius: var(--border-radius);
  box-sizing: border-box;
  font-size: var(--font-size-base);
  transition: border-color 0.2s;
}

.form-input:focus,
.form-select:focus {
  outline: none;
  border-color: var(--primary-color);
  box-shadow: 0 0 0 3px rgba(13, 93, 171, 0.1);
}

.form-input-error,
.form-select-error {
  border-color: var(--error-color);
}

.form-input-error:focus,
.form-select-error:focus {
  border-color: var(--error-color);
  box-shadow: 0 0 0 3px rgba(220, 53, 69, 0.1);
}

/* Error text styles */
.error-text {
  color: var(--error-color);
  font-size: var(--font-size-small);
  margin-top: calc(var(--spacing-unit) / 2);
  display: block;
}

/* Form container */
.form-container {
  background: white;
  padding: calc(var(--spacing-unit) * 3);
  border-radius: 10px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.form-title {
  color: var(--primary-color);
  margin-bottom: calc(var(--spacing-unit) * 3);
  font-size: 1.5rem;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: calc(var(--spacing-unit) * 2.5);
  margin-bottom: calc(var(--spacing-unit) * 3);
}

/* Button styles */
.btn {
  padding: calc(var(--spacing-unit) * 1.5) calc(var(--spacing-unit) * 3);
  border: none;
  border-radius: var(--border-radius);
  font-size: var(--font-size-base);
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.2s;
}

.btn-primary {
  background: var(--primary-color);
  color: white;
}

.btn-primary:hover {
  background: var(--primary-hover);
}

.btn-primary:disabled {
  background: #ccc;
  cursor: not-allowed;
}

.btn-secondary {
  background: #6c757d;
  color: white;
}

.btn-secondary:hover {
  background: #5a6268;
}
"""
        css_file = self.styles_dir / "forms.css"
        css_file.write_text(css_content, encoding='utf-8')
        print("  ✓ Generated forms.css")
        
        # Generate main theme CSS
        theme_css = """/* Enterprise Theme - Centralized styling */
:root {
  /* Primary Colors */
  --color-primary: #0D5DAB;
  --color-primary-dark: #002242;
  --color-primary-light: #4f7cff;
  
  /* Semantic Colors */
  --color-success: #28a745;
  --color-danger: #dc3545;
  --color-warning: #ffc107;
  --color-info: #17a2b8;
  
  /* Neutral Colors */
  --color-gray-100: #f8f9fa;
  --color-gray-200: #e9ecef;
  --color-gray-300: #dee2e6;
  --color-gray-400: #ced4da;
  --color-gray-500: #adb5bd;
  --color-gray-600: #6c757d;
  --color-gray-700: #495057;
  --color-gray-800: #343a40;
  --color-gray-900: #212529;
  
  /* Spacing */
  --spacing-xs: 0.25rem;
  --spacing-sm: 0.5rem;
  --spacing-md: 1rem;
  --spacing-lg: 1.5rem;
  --spacing-xl: 2rem;
  --spacing-2xl: 3rem;
  
  /* Typography */
  --font-family-base: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif;
  --font-size-base: 1rem;
  --font-size-sm: 0.875rem;
  --font-size-lg: 1.125rem;
  --font-weight-normal: 400;
  --font-weight-medium: 500;
  --font-weight-bold: 700;
  
  /* Borders */
  --border-radius-sm: 0.25rem;
  --border-radius-md: 0.5rem;
  --border-radius-lg: 0.75rem;
  --border-width: 1px;
  --border-color: var(--color-gray-300);
  
  /* Shadows */
  --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
  
  /* Transitions */
  --transition-fast: 150ms ease-in-out;
  --transition-base: 200ms ease-in-out;
  --transition-slow: 300ms ease-in-out;
}

/* Global Reset */
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: var(--font-family-base);
  font-size: var(--font-size-base);
  color: var(--color-gray-900);
  background-color: var(--color-gray-100);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

/* Utility Classes */
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: var(--spacing-md);
}

.section {
  margin-bottom: var(--spacing-xl);
}

.card {
  background: white;
  border-radius: var(--border-radius-md);
  box-shadow: var(--shadow-sm);
  padding: var(--spacing-lg);
  margin-bottom: var(--spacing-md);
}

.btn {
  display: inline-block;
  padding: var(--spacing-sm) var(--spacing-md);
  font-size: var(--font-size-base);
  font-weight: var(--font-weight-medium);
  border: var(--border-width) solid transparent;
  border-radius: var(--border-radius-md);
  cursor: pointer;
  transition: all var(--transition-base);
  text-decoration: none;
}

.btn-primary {
  background-color: var(--color-primary);
  color: white;
}

.btn-primary:hover {
  background-color: var(--color-primary-dark);
}

.btn-success {
  background-color: var(--color-success);
  color: white;
}

.btn-danger {
  background-color: var(--color-danger);
  color: white;
}

.btn-secondary {
  background-color: var(--color-gray-600);
  color: white;
}
"""
        theme_file = self.styles_dir / "theme.css"
        theme_file.write_text(theme_css, encoding='utf-8')
        print("  ✓ Generated theme.css")
    
    def _build_validation_code(self, field_mappings: List[Dict]) -> str:
        """Build validation code from field mappings."""
        lines = []
        
        for mapping in field_mappings:
            # Extract column name from binding for consistency with formData
            binding = mapping.get('config_binding', '')
            field_id = self._extract_column_from_binding(binding)
            
            # Fallback to config_field_id if binding extraction fails
            if not field_id:
                field_id = mapping.get('config_field_id', '')
            
            validations = mapping.get('validations', [])
            error_messages = mapping.get('error_messages', {})
            tsx_id = mapping.get('tsx_id', '')
            
            for validation in validations:
                rule = validation.get('rule', '')
                is_required = validation.get('required', False)
                error_msg = validation.get('error_message', f'{field_id} is invalid')
                
                if is_required or 'required' in rule.lower() or 'must be present' in rule.lower():
                    lines.append(f"""    // Validation: {rule}
    if (!formData.{field_id} || formData.{field_id}.toString().trim() === '') {{
      validationErrors.push({{
        field: '{tsx_id}',
        message: '{error_msg}'
      }});
    }}
""")
                
                if 'positive' in rule.lower() and 'integer' in rule.lower():
                    lines.append(f"""    // Validation: {rule}
    if (formData.{field_id} !== undefined && (isNaN(Number(formData.{field_id})) || Number(formData.{field_id}) < 1)) {{
      validationErrors.push({{
        field: '{tsx_id}',
        message: '{error_msg}'
      }});
    }}
""")
        
        return '\n'.join(lines) if lines else '    // No validations defined'
    
    def _build_field_extraction_code(self, field_mappings: List[Dict]) -> str:
        """Build code to extract field values from DOM."""
        lines = []
        
        for mapping in field_mappings:
            tsx_id = mapping.get('tsx_id', '')
            # Extract column name from binding
            binding = mapping.get('config_binding', '')
            config_id = self._extract_column_from_binding(binding)
            
            # Fallback to config_field_id if binding extraction fails
            if not config_id:
                config_id = mapping.get('config_field_id', '')
            
            if tsx_id and config_id:
                lines.append(
                    f"    {config_id}: (document.getElementById('{tsx_id}') as HTMLInputElement | null)?.value || '',"
                )
        
        return '\n'.join(lines)
    
    def _build_defaults_code(self, entity_name: str) -> str:
        """Build default values code from entity schema."""
        defaults = []
        
        # Find entity in services
        for service in self.entity_services:
            if service['entity_name'] == entity_name:
                for field in service.get('fields', []):
                    default_val = field.get('default')
                    if default_val and not field.get('auto_increment'):
                        field_name = field['name']
                        
                        # Handle special defaults
                        if default_val == 'CURRENT_TIMESTAMP':
                            defaults.append(f"      {field_name}: new Date().toISOString(),")
                        elif default_val == 'gen_random_uuid()':
                            continue  # Let server generate
                        elif default_val.isdigit():
                            defaults.append(f"      {field_name}: {default_val},")
                        else:
                            defaults.append(f"      {field_name}: '{default_val}',")
                break
        
        return '\n'.join(defaults) if defaults else ''
    
    def _build_handler_code(
        self, 
        handler_mappings: List[Dict],
        service_name: str,
        entity_class: str,
        form_type_name: str,
        field_mappings: List[Dict] = None
    ) -> str:
        """Build handler function code."""
        handlers = []
        
        for mapping in handler_mappings:
            tsx_func = mapping.get('tsx_function_name', '')
            api_method = mapping.get('target_api_method', 'POST')
            api_endpoint = mapping.get('target_api_endpoint', '')
            
            if api_method == 'POST':
                handlers.append(self._build_create_handler(
                    tsx_func, service_name, entity_class, form_type_name, field_mappings
                ))
            elif api_method == 'PUT':
                handlers.append(self._build_update_handler(
                    tsx_func, service_name, entity_class
                ))
            elif api_method == 'DELETE':
                handlers.append(self._build_delete_handler(
                    tsx_func, service_name, entity_class
                ))
        
        # If no handlers mapped, create a generic one based on screen context
        if not handlers:
            handlers.append(self._build_generic_handler(service_name, entity_class, form_type_name, field_mappings))
        
        return '\n\n'.join(handlers)
    
    def _build_create_handler(
        self, 
        func_name: str, 
        service_name: str, 
        entity_class: str,
        form_type_name: str,
        field_mappings: List[Dict] = None
    ) -> str:
        """Build create/POST handler using React Hook Form validation."""
        return f"""  /**
   * Handle create operation with React Hook Form validation
   * Validation is handled by Zod + React Hook Form before this function is called
   */
  const {func_name} = useCallback(async (formData: {form_type_name}): Promise<{entity_class} | null> => {{
    setLoading(true);

    try {{
      // Generate defaults (like tracking number) inside submit handler
      {self._generate_defaults_in_handler(field_mappings) if field_mappings else '      // No defaults to generate'}
      
      // Convert formData to API format (entity type)
      const apiData = formData as any;  // Type assertion for API call
      const result = await {service_name}.create(apiData);
      showNotification('Item created successfully', 'success');
      reset(); // Reset form after successful submission
      return result;
    }} catch (error: any) {{
      // Handle API validation errors
      if (error.response?.data?.detail) {{
        const detail = error.response.data.detail;
        
        // If detail is an object with field errors
        if (typeof detail === 'object' && !Array.isArray(detail)) {{
          Object.keys(detail).forEach((field) => {{
            setError(field as any, {{
              type: 'server',
              message: Array.isArray(detail[field]) ? detail[field][0] : detail[field]
            }});
          }});
          showNotification('Please fix the errors below', 'danger');
        }} else {{
          const message = Array.isArray(detail) ? detail[0] : detail;
      showNotification(`Operation failed: ${{message}}`, 'danger');
        }}
      }} else {{
        showNotification(`Operation failed: ${{error.message}}`, 'danger');
      }}
      return null;
    }} finally {{
      setLoading(false);
    }}
  }}, [reset, setError, showNotification]);"""
    
    def _build_update_handler(
        self, 
        func_name: str, 
        service_name: str, 
        entity_class: str
    ) -> str:
        """Build update/PUT handler."""
        return f"""  /**
   * Handle update operation
   */
  const {func_name} = useCallback(async (id: number | string, formData: Partial<{entity_class}>): Promise<{entity_class} | null> => {{
    setLoading(true);
    setErrors([]);

    try {{
      const result = await {service_name}.update(id as any, formData);
      showNotification('Item updated successfully', 'success');
      return result;
    }} catch (error: any) {{
      const message = error.response?.data?.detail 
        ? JSON.stringify(error.response.data.detail) 
        : error.message;
      showNotification(`Update failed: ${{message}}`, 'danger');
      return null;
    }} finally {{
      setLoading(false);
    }}
  }}, [showNotification]);"""
    
    def _build_delete_handler(
        self, 
        func_name: str, 
        service_name: str, 
        entity_class: str
    ) -> str:
        """Build delete handler."""
        return f"""  /**
   * Handle delete operation
   */
  const {func_name} = useCallback(async (id: number | string): Promise<boolean> => {{
    setLoading(true);

    try {{
      await {service_name}.delete(id as any);
      showNotification('Item deleted successfully', 'success');
      return true;
    }} catch (error: any) {{
      const message = error.response?.data?.detail 
        ? JSON.stringify(error.response.data.detail) 
        : error.message;
      showNotification(`Delete failed: ${{message}}`, 'danger');
      return false;
    }} finally {{
      setLoading(false);
    }}
  }}, [showNotification]);"""
    
    def _generate_default_values(self, field_mappings: List[Dict]) -> str:
        """Generate default values object for useForm."""
        defaults = []
        for mapping in field_mappings:
            binding = mapping.get('config_binding', '')
            field_id = self._extract_column_from_binding(binding) or mapping.get('config_field_id', '')
            
            # Check if field has a default (e.g., tracking number auto-generation)
            # Defaults are generated in submit handler, not here
            # This is for explicit defaults only
            
            # For now, return empty object - defaults generated in handler
            pass
        
        return "{}"
    
    def _generate_defaults_in_handler(self, field_mappings: List[Dict]) -> str:
        """Generate code to set defaults (like tracking numbers) in submit handler."""
        lines = []
        for mapping in field_mappings:
            tsx_id = mapping.get('tsx_id', '')
            binding = mapping.get('config_binding', '')
            field_id = self._extract_column_from_binding(binding) or mapping.get('config_field_id', '')
            
            # Check if this field should be auto-generated
            # Example: tracking_number auto-generation
            if 'tracking' in tsx_id.lower() or 'tracking' in field_id.lower():
                if not field_id or field_id not in ['tracking_number']:
                    continue
                lines.append(f"      // Auto-generate tracking number if blank")
                lines.append(f"      if (!formData.{field_id} || formData.{field_id}.trim() === '') {{")
                lines.append(f"        formData.{field_id} = 'TRK' + Date.now().toString().slice(-8).toUpperCase();")
                lines.append(f"      }}")
        
        return '\n'.join(lines) if lines else '      // No defaults to generate'
    
    def _generate_form_components(self):
        """Generate separate form component files (one form = one component = one hook)."""
        print("\n[5] Generating form components...")
        
        for screen_mapping in self.screen_mappings:
            field_mappings = screen_mapping.get('field_mappings', [])
            handler_mappings = screen_mapping.get('handler_mappings', [])
            
            if not field_mappings:
                continue
            
            story_id = screen_mapping.get('story_id', '')
            tsx_screen_name = screen_mapping.get('tsx_screen_name', 'UnknownScreen')
            # Use standard naming conventions based on screen name
            form_name = self._generate_form_name_from_screen(tsx_screen_name, story_id)
            hook_name = self._generate_hook_name_from_screen(tsx_screen_name, story_id)
            schema_name = self._generate_schema_name_from_screen(tsx_screen_name, story_id)
            
            # Generate form component
            self._generate_single_form_component(screen_mapping, form_name, hook_name, schema_name)
            # Generate CSS file for form
            self._generate_form_css(form_name)
    
    def _generate_single_form_component(
        self, 
        screen_mapping: Dict[str, Any],
        form_name: str,
        hook_name: str,
        schema_name: str
    ):
        """Generate a single form component following enterprise best practices."""
        field_mappings = screen_mapping.get('field_mappings', [])
        handler_mappings = screen_mapping.get('handler_mappings', [])
        story_id = screen_mapping['story_id']
        hook_var_suffix = self._normalize_name(story_id.replace(' ', ''))
        register_name = f"register{hook_var_suffix}"
        errors_name = f"errors{hook_var_suffix}"
        handle_submit_name = f"handleSubmit{hook_var_suffix}"
        
        # Get submit handler name
        submit_handler = "processSubmit"
        if handler_mappings:
            submit_handler = handler_mappings[0].get('tsx_function_name', 'processSubmit')
        
        # Generate form fields using reusable components
        form_fields = []
        for mapping in field_mappings:
            tsx_id = mapping.get('tsx_id', '')
            binding = mapping.get('config_binding', '')
            field_id = self._extract_column_from_binding(binding) or mapping.get('config_field_id', '')
            label = mapping.get('tsx_label') or mapping.get('config_label', '')
            
            if not field_id:
                continue
            
            # Determine field type
            validations = mapping.get('validations', [])
            # Check data_type from config for more accurate type detection
            data_type = mapping.get('data_type', '').lower()
            
            # Determine if field is numeric (for valueAsNumber option)
            # Only use valueAsNumber if explicitly numeric AND not a format/regex field
            is_number = False
            has_format_validation = any(
                'format' in v.get('rule', '').lower() or 
                'regex' in v.get('rule', '').lower() or 
                'must be valid' in v.get('rule', '').lower() or
                'tracking number' in v.get('rule', '').lower()
                for v in validations
            )
            
            if not has_format_validation:
                is_number = (
                    'integer' in data_type or 
                    'number' in data_type or 
                    'float' in data_type or
                    any(
                        ('integer' in v.get('rule', '').lower() or 'number' in v.get('rule', '').lower()) and
                        'format' not in v.get('rule', '').lower() and
                        'regex' not in v.get('rule', '').lower()
                        for v in validations
                    )
                )
            
            is_select = mapping.get('element_type') == 'select' or data_type == 'dropdown'
            
            if is_select:
                # Generate FormSelect
                options = self._extract_select_options(mapping)
                form_fields.append(f"""        <FormSelect
          id="{tsx_id}"
          label="{label}"
          register={{{register_name}}}
          fieldName="{field_id}"
          error={{{errors_name}.{field_id}}}
          options={{{options}}}
          placeholder="Select {label.lower()}"
        />""")
            else:
                # Generate FormInput
                input_type = 'number' if is_number else 'text'
                value_as_number = 'valueAsNumber' if is_number else ''
                # Build props string with proper JSX syntax
                props = []
                if value_as_number:
                    props.append('valueAsNumber={true}')
                
                props_str = '\n          '.join(props) if props else ''
                if props_str:
                    props_str = '\n          ' + props_str
                
                form_fields.append(f"""        <FormInput
          id="{tsx_id}"
          label="{label}"
          type="{input_type}"
          register={{{register_name}}}
          fieldName="{field_id}"
          error={{{errors_name}.{field_id}}}
          placeholder="Enter {label.lower()}"{props_str}
        />""")
        
        form_component = f"""// Enterprise-ready form component
// One form = one hook = one Zod schema
import React from 'react';
import {{ {hook_name} }} from '../../hooks/{hook_name}';
import {{ FormInput }} from '../../components/FormInput/FormInput';
import {{ FormSelect }} from '../../components/FormSelect/FormSelect';
import {{ useNotification }} from '../../components/Notification/Notification';
import './{form_name}.css';

interface {form_name}Props {{
  onSubmitSuccess?: () => void;
}}

export const {form_name}: React.FC<{form_name}Props> = ({{ onSubmitSuccess }}) => {{
  const {{ showNotification }} = useNotification();
  const {{
    register: {register_name},
    handleSubmit: {handle_submit_name},
    errors: {errors_name},
    loading,
    {submit_handler}
  }} = {hook_name}(showNotification);

  const onSubmit = {handle_submit_name}(async (formData) => {{
    try {{
      await {submit_handler}(formData);
      onSubmitSuccess?.();
    }} catch (error) {{
      // Error handling done in hook
    }}
  }});

  return (
    <form onSubmit={{onSubmit}} className="form-container">
      <h3 className="form-title">{story_id}</h3>
      <div className="form-grid">
{chr(10).join(form_fields)}
      </div>
      <button type="submit" className="btn btn-primary" disabled={{loading}}>
        {{loading ? 'Submitting...' : 'Submit'}}
      </button>
    </form>
  );
}};

export default {form_name};
"""
        # Create subfolder for form component
        form_subdir = self.forms_dir / form_name
        form_subdir.mkdir(parents=True, exist_ok=True)
        form_file = form_subdir / f"{form_name}.tsx"
        form_file.write_text(form_component, encoding='utf-8')
        print(f"  ✓ Generated {form_name}/{form_name}.tsx")
    
    def _generate_form_css(self, form_name: str):
        """Generate CSS file for form component."""
        css_content = f"""/* CSS for {form_name} component */
/* Uses centralized form styles from ../styles/forms.css */

.{form_name.lower()} {{
  /* Form-specific styles can be added here if needed */
}}
"""
        # CSS file goes in the same subfolder as the form component
        form_subdir = self.forms_dir / form_name
        css_file = form_subdir / f"{form_name}.css"
        css_file.write_text(css_content, encoding='utf-8')
        print(f"  ✓ Generated {form_name}/{form_name}.css")
    
    def _generate_screen_components(self):
        """Generate screen-level components from TSX metadata."""
        print("\n[6] Generating screen components...")
        
        if not self.tsx_metadata:
            print("  [INFO] No TSX metadata available - skipping screen component generation")
            return
        
        screens = self.tsx_metadata.get('screens', [])
        if not screens:
            print("  [INFO] No screens found in metadata - skipping screen component generation")
            return
        
        generated_count = 0
        for screen_data in screens:
            screen_name = screen_data.get('component_name', '')
            if not screen_name or screen_name == 'UnknownScreen':
                continue
            
            # Generate screen component
            screen_base = screen_name.replace('Screen', '').replace('screen', '')
            if not screen_base:
                continue
            
            component_name = f"{screen_base}Screen"
            file_name = f"{component_name}.tsx"
            
            # Find corresponding screen mapping for props and hooks
            screen_mapping = None
            for mapping in self.screen_mappings:
                if mapping.get('tsx_screen_name') == screen_name:
                    screen_mapping = mapping
                    break
            
            # Generate screen component
            hook_name = None
            form_name = None
            if screen_mapping:
                story_id = screen_mapping.get('story_id', '')
                hook_name = self._generate_hook_name_from_screen(screen_name, story_id)
                form_name = self._generate_form_name_from_screen(screen_name, story_id)
            
            screen_component = f"""// Screen component: {component_name}
// Extracted from main TSX for better maintainability
import React from 'react';
{f'import {{ {hook_name} }} from \'../../hooks/{hook_name}\';' if hook_name else ''}
{f'import {{ {form_name} }} from \'../../forms/{form_name}/{form_name}\';' if form_name else ''}
import {{ useNotification }} from '../../components/Notification/Notification';
import './{component_name}.css';

interface {component_name}Props {{
  // Add screen-specific props here
}}

export const {component_name}: React.FC<{component_name}Props> = () => {{
  const {{ showNotification }} = useNotification();
{f'  const {{ /* Add hook destructuring here if needed */ }} = {hook_name}(showNotification);' if hook_name else ''}
  
  return (
    <div className="{component_name.lower()}">
      <div className="screen-header">
        <h1>{component_name.replace('Screen', '')}</h1>
      </div>
      
      <div className="screen-content">
        {{/* Screen content will be wired from main TSX */}}
        {{/* TODO: Extract screen JSX content from main TSX file */}}
        {f'<{form_name} />' if form_name else '<p>Screen content</p>'}
      </div>
    </div>
  );
}};

export default {component_name};
"""
            
            # Create subfolder for screen component
            screen_subdir = self.screens_dir / component_name
            screen_subdir.mkdir(parents=True, exist_ok=True)
            component_file = screen_subdir / file_name
            component_file.write_text(screen_component, encoding='utf-8')
            
            # Generate CSS for screen
            screen_css = f"""/* Styles for {component_name} */
.{component_name.lower()} {{
  padding: var(--spacing-lg, 1.5rem);
}}

.{component_name.lower()} .screen-header {{
  background: linear-gradient(135deg, var(--color-primary-dark, #002242), var(--color-gray-800, #343a40));
  color: white;
  padding: var(--spacing-lg, 1.5rem);
  border-radius: var(--border-radius-md, 0.5rem);
  margin-bottom: var(--spacing-xl, 2rem);
}}

.{component_name.lower()} .screen-header h1 {{
  margin: 0;
  font-size: 1.75rem;
  font-weight: var(--font-weight-bold, 700);
}}

.{component_name.lower()} .screen-content {{
  background: white;
  border-radius: var(--border-radius-md, 0.5rem);
  box-shadow: var(--shadow-sm, 0 1px 2px 0 rgba(0, 0, 0, 0.05));
  padding: var(--spacing-xl, 2rem);
}}
"""
            css_file = screen_subdir / f"{component_name}.css"
            css_file.write_text(screen_css, encoding='utf-8')
            
            generated_count += 1
            print(f"  ✓ Generated {component_name}/{component_name}.tsx and {component_name}/{component_name}.css")
        
        if generated_count > 0:
            print(f"  ✓ Generated {generated_count} screen component(s)")
        else:
            print("  [INFO] No screen components generated")
    
    def _extract_select_options(self, mapping: Dict) -> str:
        """Extract select options from field mapping or schema."""
        # This would need to look up enum values from schema or config
        # For now, return empty array - will be populated from schema
        return "[]"  # TODO: Extract from schema enums
    
    def _inject_component_imports(self, lines: List[str]) -> List[str]:
        """Inject imports for reusable components."""
        # Find last import
        last_import_idx = -1
        for i, line in enumerate(lines):
            if line.strip().startswith('import '):
                last_import_idx = i
        
        if last_import_idx >= 0:
            component_imports = [
                "",
                "// Reusable component imports",
                "import { FormInput } from './components/FormInput/FormInput';",
                "import { FormSelect } from './components/FormSelect/FormSelect';",
                "import { ErrorText } from './components/ErrorText/ErrorText';",
                "import { Modal } from './components/Modal/Modal';",
                "import { NotificationProvider, useNotification } from './components/Notification/Notification';",
                "import './styles/forms.css';",
                ""
            ]
            return lines[:last_import_idx + 1] + component_imports + lines[last_import_idx + 1:]
        
        return lines
    
    def _inject_notification_provider(self, lines: List[str]) -> List[str]:
        """Wrap app with NotificationProvider."""
        # Find the main component return statement
        # This is complex - for now, just inject the provider import
        # The actual wrapping would need more sophisticated parsing
        return lines
    
    def _wrap_forms_in_form_elements(self, lines: List[str]) -> List[str]:
        """Wrap form fields in <form> elements with onSubmit handlers."""
        # This is complex - needs to identify form boundaries and wrap them
        # For now, return lines as-is - will be handled by form component generation
        return lines
    
    def _replace_fields_with_reusable_components(self, lines: List[str]) -> List[str]:
        """Replace input/select fields with reusable FormInput/FormSelect components."""
        # This is complex - needs to replace entire field blocks
        # For now, return lines as-is - will be handled by form component generation
        return lines
    
    def _remove_inline_styles(self, lines: List[str]) -> List[str]:
        """Remove inline styles and replace with CSS classes."""
        # Replace style={{...}} with className
        # This is complex - would need to map styles to classes
        # For now, return lines as-is - CSS classes will be used in new form components
        return lines
    
    def _add_css_import_to_app(self, lines: List[str], output_path: Path):
        """Add CSS import to main app file."""
        # Add import at top if not present
        content = output_path.read_text(encoding='utf-8')
        if "import './styles/forms.css'" not in content:
            # Find last import and add CSS import
            lines_list = content.splitlines()
            last_import_idx = -1
            for i, line in enumerate(lines_list):
                if line.strip().startswith('import '):
                    last_import_idx = i
            
            if last_import_idx >= 0:
                lines_list.insert(last_import_idx + 1, "import './styles/forms.css';")
                output_path.write_text('\n'.join(lines_list), encoding='utf-8')
    
    def _build_generic_handler(self, service_name: str, entity_class: str, form_type_name: str = None, field_mappings: List[Dict] = None) -> str:
        """Build generic create handler when no specific mapping exists."""
        if not form_type_name:
            form_type_name = f"{entity_class}Create"
        
        defaults_code = ""
        if field_mappings:
            defaults_code = self._generate_defaults_in_handler(field_mappings)
            if defaults_code:
                defaults_code = "\n      " + defaults_code.replace("\n", "\n      ")
        
        return f"""  /**
   * Handle form submission with React Hook Form validation
   * Validation is handled by Zod + React Hook Form before this function is called
   */
  const processSubmit = useCallback(async (formData: {form_type_name}): Promise<{entity_class} | null> => {{
    setLoading(true);

    try {{
      // Generate defaults (like tracking number) inside submit handler
      {defaults_code}
      
      const apiData = formData as any;  // Type assertion for API call
      const result = await {service_name}.create(apiData);
      showNotification('Operation successful', 'success');
      reset(); // Reset form after successful submission
      return result;
    }} catch (error: any) {{
      // Handle API validation errors
      if (error.response?.data?.detail) {{
        const detail = error.response.data.detail;
        
        if (typeof detail === 'object' && !Array.isArray(detail)) {{
          Object.keys(detail).forEach((field) => {{
            setError(field as any, {{
              type: 'server',
              message: Array.isArray(detail[field]) ? detail[field][0] : detail[field]
            }});
          }});
          showNotification('Please fix the errors below', 'danger');
        }} else {{
          const message = Array.isArray(detail) ? detail[0] : detail;
      showNotification(`Operation failed: ${{message}}`, 'danger');
        }}
      }} else {{
        showNotification(`Operation failed: ${{error.message}}`, 'danger');
      }}
      return null;
    }} finally {{
      setLoading(false);
    }}
  }}, [reset, setError, showNotification]);"""
    
    def _build_handler_type_signatures(self, handler_mappings: List[Dict]) -> str:
        """Build TypeScript type signatures for handlers."""
        signatures = []
        
        for mapping in handler_mappings:
            func_name = mapping.get('tsx_function_name', '')
            api_method = mapping.get('target_api_method', 'POST')
            
            if api_method == 'POST':
                signatures.append(f"{func_name}: (formData: any) => Promise<any>;")
            elif api_method == 'PUT':
                signatures.append(f"{func_name}: (id: any, formData: any) => Promise<any>;")
            elif api_method == 'DELETE':
                signatures.append(f"{func_name}: (id: any) => Promise<boolean>;")
        
        if not signatures:
            signatures.append("processSubmit: (formData: any) => Promise<any>;")
        
        return '\n  '.join(signatures)
    
    def _build_handler_return_list(self, handler_mappings: List[Dict]) -> str:
        """Build list of handlers to return from hook."""
        handlers = [m.get('tsx_function_name', '') for m in handler_mappings if m.get('tsx_function_name')]
        
        if not handlers:
            handlers = ['processSubmit']
        
        return ',\n    '.join(handlers)
    
    def _generate_infrastructure(self):
        """Generate package.json, tsconfig, etc."""
        print("\n[4] Generating infrastructure files...")
        
        # package.json
        pkg = {
            "name": self._to_camel_case(self.app_name),
            "version": "1.0.0",
            "private": True,
            "dependencies": {
                "react": "^18.2.0",
                "react-dom": "^18.2.0",
                "react-scripts": "5.0.1",
                "axios": "^1.6.0",
                "typescript": "^4.9.5",
                "react-hook-form": "^7.48.0",
                "zod": "^3.22.0",
                "@hookform/resolvers": "^3.3.0"
            },
            "devDependencies": {
                "@types/react": "^18.2.0",
                "@types/react-dom": "^18.2.0"
            },
            "scripts": {
                "start": "react-scripts start",
                "build": "react-scripts build",
                "test": "react-scripts test"
            },
            "browserslist": [">0.2%", "not dead", "not op_mini all"]
        }
        (self.output_dir / 'package.json').write_text(
            json.dumps(pkg, indent=2), encoding='utf-8'
        )
        print("  ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ Generated package.json")
        
        # tsconfig.json
        tsconfig = {
            "compilerOptions": {
                "target": "es5",
                "lib": ["dom", "dom.iterable", "esnext"],
                "allowJs": True,
                "skipLibCheck": True,
                "esModuleInterop": True,
                "allowSyntheticDefaultImports": True,
                "strict": True,
                "forceConsistentCasingInFileNames": True,
                "noFallthroughCasesInSwitch": True,
                "module": "esnext",
                "moduleResolution": "node",
                "resolveJsonModule": True,
                "isolatedModules": True,
                "noEmit": True,
                "jsx": "react-jsx"
            },
            "include": ["src"]
        }
        (self.output_dir / 'tsconfig.json').write_text(
            json.dumps(tsconfig, indent=2), encoding='utf-8'
        )
        print("  ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ Generated tsconfig.json")
        
        # .env
        (self.output_dir / '.env').write_text(
            "REACT_APP_API_URL=http://localhost:8000", encoding='utf-8'
        )
        print("  ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ Generated .env")
        
        # public/index.html
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>{self.app_name}</title>
</head>
<body>
  <noscript>You need to enable JavaScript to run this app.</noscript>
  <div id="root"></div>
</body>
</html>
"""
        (self.output_dir / "public" / "index.html").write_text(html, encoding='utf-8')
        print("  ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ Generated public/index.html")
        
        # src/index.tsx
        index_tsx = f"""import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './{self.output_tsx_name[:-4]}';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
"""
        (self.src_dir / "index.tsx").write_text(index_tsx, encoding='utf-8')
        print("  ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ Generated src/index.tsx")
        
        # react-app-env.d.ts
        (self.src_dir / 'react-app-env.d.ts').write_text(
            '/// <reference types="react-scripts" />', encoding='utf-8'
        )
        print("  ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ Generated react-app-env.d.ts")
    
    def _process_tsx(self):
        """Process and wire the TSX file."""
        print("\n[5] Processing TSX file...")
        
        # Find input TSX file
        input_tsx_candidates = [
            self.input_dir / "ui_react_component.tsx",
            self.input_dir / f"{self.app_name_normalized}.tsx",
        ]
        
        input_tsx = None
        for candidate in input_tsx_candidates:
            if candidate.exists():
                input_tsx = candidate
                break
        
        if not input_tsx:
            # Search for any .tsx file
            tsx_files = list(self.input_dir.glob("*.tsx"))
            if tsx_files:
                input_tsx = tsx_files[0]
        
        if not input_tsx or not input_tsx.exists():
            print(f"  [WARNING] No input TSX file found in {self.input_dir}")
            return
        
        print(f"  Input: {input_tsx}")
        
        # Read content
        content = input_tsx.read_text(encoding='utf-8')
        lines = content.splitlines()
        
        # Generate enterprise-ready form components (one form = one component = one hook)
        self._generate_form_components()
        
        # Process in order (ID injection FIRST to preserve line numbers from metadata)
        lines = self._add_missing_input_ids(lines)
        lines = self._remove_mock_data(lines)
        lines = self._inject_imports(lines)
        lines = self._inject_component_imports(lines)  # Import reusable components
        lines = self._inject_notification_provider(lines)  # Wrap app with NotificationProvider
        lines = self._inject_hook_calls_at_component_level(lines)
        lines = self._wire_all_form_fields(lines)  # CRITICAL: Wire fields with React Hook Form register
        lines = self._wrap_forms_in_form_elements(lines)  # Wrap forms in <form> with onSubmit
        lines = self._replace_fields_with_reusable_components(lines)  # Use FormInput, FormSelect (optional - can be done later)
        lines = self._remove_inline_styles(lines)  # Replace with CSS classes
        lines = self._wire_handlers(lines)
        lines = self._add_api_data_loading(lines)
        
        # Apply TypeScript fixes
        final_content = '\n'.join(lines)
        final_content = self._fix_typescript_types(final_content)
        
        # Write output
        output_path = self.src_dir / self.output_tsx_name
        output_path.write_text(final_content, encoding='utf-8')
        print(f"  ✓ Generated {self.output_tsx_name}")
        
        # Also import CSS
        self._add_css_import_to_app(lines, output_path)
    
    def _add_missing_input_ids(self, lines: List[str]) -> List[str]:
        """
        Inject IDs into TSX fields that were auto-generated by Step 06.
        
        This method finds all fields in tsx_metadata with 'id_generated: true'
        and injects the ID attribute into the corresponding TSX line.
        
        Args:
            lines: TSX file content as list of lines (0-indexed)
            
        Returns:
            Modified lines with IDs injected
            
        Example:
            Input:  <input type="checkbox" />
            Output: <input id="dashboardField256" type="checkbox" />
        """
        if not self.tsx_metadata:
            print("  - Skipping ID injection (no tsx_metadata provided)")
            return lines
        
        print("  - Injecting missing IDs from tsx_metadata.json...")
        
        # Extract all fields that need ID injection
        fields_to_inject = []
        screens = self.tsx_metadata.get('screens', [])
        
        for screen in screens:
            for field in screen.get('fields', []):
                if field.get('id_generated', False):
                    fields_to_inject.append(field)
        
        if not fields_to_inject:
            print("    [INFO] No fields require ID injection")
            return lines
        
        # Inject IDs
        injected_count = 0
        skipped_count = 0
        
        for field in fields_to_inject:
            tsx_id = field.get('tsx_id')
            line_number = field.get('line_number')  # 1-indexed
            element_type = field.get('element_type', 'input')
            
            if not tsx_id or not line_number:
                skipped_count += 1
                continue
            
            # Convert to 0-indexed
            line_index = line_number - 1
            
            # Validate line index
            if line_index < 0 or line_index >= len(lines):
                print(f"    [WARN] Line {line_number} out of bounds for field '{tsx_id}'")
                skipped_count += 1
                continue
            
            # Get the line
            original_line = lines[line_index]
            
            # Create regex pattern to inject ID as first attribute
            # Matches: <input ...> or <select ...> or <textarea ...>
            # Captures: opening tag, existing attributes, closing
            pattern = rf'(<{element_type}\s+)(.*?)(/?>\s*)$'
            
            # Check if line matches pattern
            match = re.search(pattern, original_line, re.IGNORECASE)
            if not match:
                # Try pattern without space after tag name (e.g., <input/>)
                pattern_no_space = rf'(<{element_type})(/?>\s*)$'
                match_no_space = re.search(pattern_no_space, original_line, re.IGNORECASE)
                
                if match_no_space:
                    # Inject ID when no existing attributes
                    replacement = rf'\1 id="{tsx_id}"\2'
                    modified_line = re.sub(pattern_no_space, replacement, original_line, flags=re.IGNORECASE)
                    lines[line_index] = modified_line
                    print(f"    ÃƒÂ¢Ã…â€œÃ¢â‚¬Å“ Injected ID '{tsx_id}' at line {line_number}")
                    injected_count += 1
                else:
                    print(f"    [WARN] Pattern mismatch at line {line_number} for field '{tsx_id}'")
                    skipped_count += 1
                continue
            
            # Inject ID as first attribute
            # Format: <input id="tsx_id" existing_attributes />
            replacement = rf'\1id="{tsx_id}" \2\3'
            modified_line = re.sub(pattern, replacement, original_line, flags=re.IGNORECASE)
            
            # Update the line
            lines[line_index] = modified_line
            print(f"    ÃƒÂ¢Ã…â€œÃ¢â‚¬Å“ Injected ID '{tsx_id}' at line {line_number}")
            injected_count += 1
        
        # Summary
        print(f"    [INFO] ID injection complete: {injected_count} injected, {skipped_count} skipped")
        
        return lines
    
    def _remove_mock_data(self, lines: List[str]) -> List[str]:
        """Remove mock data from useState declarations."""
        print("  - Removing mock data...")
        
        for mock_loc in self.mock_data_removal:
            var_name = mock_loc.get('variable_name', '')
            action = mock_loc.get('action', 'replace_with_empty_array')
            
            # Find the useState line for this variable
            for i, line in enumerate(lines):
                if f'const [{var_name},' in line and 'useState' in line:
                    # Find the end of this statement
                    start_line = i
                    bracket_count = 0
                    in_statement = False
                    end_line = i
                    
                    for j in range(i, min(i + 100, len(lines))):
                        for char in lines[j]:
                            if char == '[':
                                bracket_count += 1
                                in_statement = True
                            elif char == ']':
                                bracket_count -= 1
                        
                        if in_statement and bracket_count == 0:
                            end_line = j
                            break
                    
                    # Replace with empty array
                    setter_name = f"set{var_name[0].upper()}{var_name[1:]}"
                    replacement = f"  const [{var_name}, {setter_name}] = useState<any[]>([]);"
                    
                    lines = lines[:start_line] + [replacement] + lines[end_line + 1:]
                    print(f"    ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ Cleared mock data from {var_name}")
                    break
        
        return lines
    
    def _inject_imports(self, lines: List[str]) -> List[str]:
        """Inject service and hook imports."""
        print("  - Injecting imports...")
        
        new_imports = [
            "",
            "// Auto-generated imports",
        ]
        
        # Add service imports
        for service in self.entity_services:
            service_name = service['service_name']
            new_imports.append(f"import {service_name} from './services/{service_name}';")
        
        # Add hook imports
        for screen in self.screen_mappings:
            story_id = screen.get('story_id', '')
            tsx_screen_name = screen.get('tsx_screen_name', 'UnknownScreen')
            hook_name = self._generate_hook_name_from_screen(tsx_screen_name, story_id)
            new_imports.append(f"import {{ {hook_name} }} from './hooks/{hook_name}';")
        
        # Add type imports
        entity_names = [self._normalize_name(s['entity_name']) for s in self.entity_services]
        if entity_names:
            new_imports.append(f"import {{ {', '.join(entity_names)} }} from './types/entities';")
        
        new_imports.append("")
        
        # Find last import line
        last_import_idx = -1
        for i, line in enumerate(lines):
            if line.strip().startswith('import '):
                last_import_idx = i
        
        if last_import_idx >= 0:
            return lines[:last_import_idx + 1] + new_imports + lines[last_import_idx + 1:]
        else:
            return new_imports + lines
    
    def _wire_all_form_fields(self, lines: List[str]) -> List[str]:
        """Wire all form fields with React Hook Form register."""
        print("  - Wiring form fields with React Hook Form...")
        
        # Build a map of tsx_id -> screen_name from tsx_metadata
        field_to_screen_map = {}
        if self.tsx_metadata:
            for screen_data in self.tsx_metadata.get('screens', []):
                screen_name = screen_data.get('component_name', '')
                for field in screen_data.get('fields', []):
                    tsx_id = field.get('tsx_id', '')
                    if tsx_id:
                        field_to_screen_map[tsx_id] = screen_name
        
        total_fields_wired = 0
        for screen in self.screen_mappings:
            field_mappings = screen.get('field_mappings', [])
            story_id = screen.get('story_id', '')
            tsx_screen_name = screen.get('tsx_screen_name', '')
            
            if not story_id or not field_mappings:
                continue
            
            # Get the hook variable name suffix to determine which register to use
            # Use standard naming for hook variable suffix
            screen_base = tsx_screen_name.replace('Screen', '').replace('screen', '')
            if not screen_base:
                screen_base = self._normalize_name(story_id.replace(' ', '').replace('User', '').replace('Story', ''))
            hook_var_suffix = screen_base
            register_name = f"register{hook_var_suffix}"
            errors_name = f"errors{hook_var_suffix}"
            
            print(f"    Processing screen '{tsx_screen_name}' with {len(field_mappings)} fields using {register_name}")
            
            # Wire each mapped field
            # SOURCE OF TRUTH: Use config_field_id from application_config.json
            fields_wired_count = 0
            for mapping in field_mappings:
                tsx_id = mapping.get('tsx_id', '')  # Used to find DOM element
                binding = mapping.get('config_binding', '')
                # IMPORTANT: config_field_id is source of truth (overwrites any TSX field ID)
                field_id = self._extract_column_from_binding(binding) or mapping.get('config_field_id', '')
                
                if not tsx_id or not field_id:
                    continue
                
                # Log field mapping for debugging (helps identify case conflicts)
                # This shows when application_config.json field ID overwrites TSX field ID
                if tsx_id.lower() != field_id.lower():
                    print(f"    [MAP] TSX ID '{tsx_id}' -> Config ID '{field_id}' (application_config.json overwrites - config is source of truth)")
                
                # Verify this field belongs to this screen (prevent cross-screen wiring)
                if tsx_id in field_to_screen_map:
                    actual_screen_name = field_to_screen_map[tsx_id]
                    if actual_screen_name != tsx_screen_name:
                        # Skip - field belongs to a different screen
                        print(f"    [SKIP] Field '{tsx_id}' belongs to '{actual_screen_name}', not '{tsx_screen_name}'")
                        continue
                
                # Find input/select/textarea with this id
                # CRITICAL: Must register ALL fields for React Hook Form validation to work
                # According to React Hook Form docs: {...register('fieldName')} must be spread on input elements
                field_found = False
                register_added_for_field = False
                field_line_idx = -1
                
                # Search for the field in TSX - iterate through all lines
                for i, line in enumerate(lines):
                    # Check for id attribute with this tsx_id (both double and single quotes)
                    if f'id="{tsx_id}"' in line or f"id='{tsx_id}'" in line:
                        field_found = True
                        field_found = True
                        # Check if already registered (check current and nearby lines)
                        already_registered = False
                        for check_idx in range(max(0, i-3), min(len(lines), i+3)):
                            check_line = lines[check_idx]
                            if (f'{{...{register_name}(' in check_line or 
                                f'{register_name}(' in check_line):
                                already_registered = True
                                break
                        
                        if already_registered:
                            # Field already registered, skip to next field
                            break
                        
                        # Check if this is part of an input/select/textarea (check current and up to 5 previous lines)
                        is_input_element = False
                        for check_idx in range(max(0, i-5), i+1):
                            check_line = lines[check_idx]
                            if '<input' in check_line or '<select' in check_line or '<textarea' in check_line:
                                is_input_element = True
                                break
                        
                        if is_input_element:
                            # CRITICAL: Add register spread for React Hook Form validation
                            # Use string replacement for reliable matching
                            original_line = line
                            
                            # Build register spread string
                            if f'id="{tsx_id}"' in line:
                                register_spread = f'{{...{register_name}("{field_id}")}}'
                                new_line = line.replace(
                                    f'id="{tsx_id}"',
                                    f'id="{tsx_id}" {register_spread}'
                                )
                            elif f"id='{tsx_id}'" in line:
                                register_spread = f"{{...{register_name}('{field_id}')}}"
                                new_line = line.replace(
                                    f"id='{tsx_id}'",
                                    f"id='{tsx_id}' {register_spread}"
                                )
                            else:
                                new_line = original_line
                            
                            # Replace the line if it changed
                            if new_line != original_line:
                                lines[i] = new_line
                                register_added_for_field = True
                                field_line_idx = i
                                print(f"    [WIRE] ✓ Registered '{tsx_id}' -> '{field_id}' with {register_name} (line {i+1})")
                                # Break from loop after successful registration
                                break
                        # If field ID found but not an input, continue searching
                        # (in case there are multiple elements with same ID, unlikely but possible)
                
                # Add error display and conditional styling if register was successfully added
                if register_added_for_field and field_line_idx >= 0:
                    # Find where the input/select/textarea tag actually closes
                    # CRITICAL: Must find the ACTUAL closing tag, not just the opening tag's closing bracket
                    closing_line_idx = -1
                    element_type = None
                    
                    # First, determine the element type by checking the opening line
                    opening_line = lines[field_line_idx]
                    if '<select' in opening_line.lower() or any('<select' in lines[max(0, field_line_idx-i)] for i in range(min(5, field_line_idx+1))):
                        element_type = 'select'
                    elif '<textarea' in opening_line.lower() or any('<textarea' in lines[max(0, field_line_idx-i)] for i in range(min(5, field_line_idx+1))):
                        element_type = 'textarea'
                    else:
                        element_type = 'input'
                    
                    # Search for the actual closing tag (look further if needed for multi-line elements)
                    for j in range(field_line_idx, min(field_line_idx + 20, len(lines))):
                        line_content = lines[j]
                        # Check for self-closing tag first (/>)
                        if '/>' in line_content and (j == field_line_idx or j > field_line_idx):
                            closing_line_idx = j
                            break
                        # Check for separate closing tag based on element type
                        elif element_type == 'select' and '</select>' in line_content:
                            closing_line_idx = j
                            break
                        elif element_type == 'textarea' and '</textarea>' in line_content:
                            closing_line_idx = j
                            break
                    
                    # If we found a closing tag, add error display AFTER it
                    if closing_line_idx >= field_line_idx:
                        # Use ErrorText component for consistent red styling
                        # Match the indentation of the closing tag
                        closing_line = lines[closing_line_idx]
                        indent_match = re.match(r'^(\s*)', closing_line)
                        indent = indent_match.group(1) if indent_match else "            "
                        
                        error_display = f"{indent}{{{errors_name}.{field_id} && ("
                        error_display += f"\n{indent}  <ErrorText id=\"{tsx_id}-error\" message={{{errors_name}.{field_id}.message || 'Invalid value'}} />"
                        error_display += f"\n{indent})}}"
                        lines.insert(closing_line_idx + 1, error_display)
                    
                    # Update input field border to red when there's an error
                    # Modify the style attribute to add conditional red border
                    # Re-read current line after register was added (line may have changed)
                    current_line = lines[field_line_idx]
                            
                    # Find the line with style attribute (check current and next lines)
                    style_line_idx = field_line_idx
                    style_line = current_line
                    
                    # Check current line first, then next line (style often follows id on same line)
                    if 'style={{' not in current_line:
                        # Check next line
                        if field_line_idx + 1 < len(lines) and 'style={{' in lines[field_line_idx + 1]:
                            style_line_idx = field_line_idx + 1
                            style_line = lines[field_line_idx + 1]
                        # Check previous line
                        elif field_line_idx > 0 and 'style={{' in lines[field_line_idx - 1]:
                            style_line_idx = field_line_idx - 1
                            style_line = lines[field_line_idx - 1]
                            
                            if 'style={{' in style_line:
                                # Extract style object and add conditional border
                                # Pattern: style={{ ... }}
                                style_match = re.search(r'style=\{\{(.*?)\}\}', style_line, re.DOTALL)
                                if style_match:
                                    existing_style = style_match.group(1).strip()
                                    
                                    # Check if border already exists and remove it
                                    has_border = re.search(r'\bborder\s*:', existing_style)
                                    
                                    if has_border:
                                        # Remove existing border declaration
                                        existing_style = re.sub(
                                            r"\bborder\s*:\s*['\"][^'\"]*['\"]\s*,?\s*",
                                            "",
                                            existing_style
                                        )
                                        # Clean up any double commas or trailing commas
                                        existing_style = re.sub(r',\s*,', ',', existing_style).strip()
                                        if existing_style.endswith(','):
                                            existing_style = existing_style[:-1].strip()
                                    
                                    # Add conditional border at the end
                                    if existing_style:
                                        existing_style = existing_style.rstrip().rstrip(',')
                                        new_style_content = existing_style + ", border: " + errors_name + "." + field_id + " ? '1px solid #dc3545' : '1px solid #ddd'"
                                    else:
                                        new_style_content = "border: " + errors_name + "." + field_id + " ? '1px solid #dc3545' : '1px solid #ddd'"
                                    
                                    # Build style attribute: style={{ ... }} in JSX
                                    new_style_attr = "style={{ " + new_style_content + " }}"
                                    
                                    # Replace in the style line
                                    lines[style_line_idx] = re.sub(
                                        r'style=\{\{.*?\}\}',
                                        new_style_attr,
                                        style_line,
                                        flags=re.DOTALL
                                    )
                            elif 'style=' not in style_line:
                                # No style attribute - add one with conditional border
                                border_expr = errors_name + "." + field_id + " ? '1px solid #dc3545' : '1px solid #ddd'"
                                conditional_style = "style={{ border: " + border_expr + " }}"
                                
                                if '/>' in current_line:
                                    lines[field_line_idx] = current_line.replace('/>', ' ' + conditional_style + ' />')
                                elif '>' in current_line:
                                    lines[field_line_idx] = current_line.replace('>', ' ' + conditional_style + '>')
                
                # Check if field was found but not registered
                if field_found and not register_added_for_field:
                    print(f"    [WARN] Field '{tsx_id}' (config: '{field_id}') found but could not be registered")
                
                if not field_found:
                    print(f"    [WARN] Field '{tsx_id}' (config: '{field_id}') not found in TSX - cannot register")
        
        print(f"    ✓ Wired form fields with React Hook Form register ({fields_wired_count} fields registered)")
        return lines
    
    def _wire_handlers(self, lines: List[str]) -> List[str]:
        """Wire handler functions to use hooks."""
        print("  - Wiring handlers...")
        
        for screen in self.screen_mappings:
            for handler in screen.get('handler_mappings', []):
                tsx_func = handler.get('tsx_function_name', '')
                if tsx_func:
                    lines = self._wire_single_handler(lines, tsx_func, screen)
        
        return lines
    
    def _wire_single_handler(
        self, 
        lines: List[str], 
        handler_name: str,
        screen: Dict
    ) -> List[str]:
        """Wire a single handler function using React Hook Form."""
        story_id = screen.get('story_id', '')
        tsx_screen_name = screen.get('tsx_screen_name', 'UnknownScreen')
        # Use standard naming for hook variable suffix
        screen_base = tsx_screen_name.replace('Screen', '').replace('screen', '')
        if not screen_base:
            screen_base = self._normalize_name(story_id.replace(' ', '').replace('User', '').replace('Story', ''))
        hook_var_suffix = screen_base
        handle_submit_name = f"handleSubmit{hook_var_suffix}"
        
        # Find the handler function
        handler_start = -1
        for i, line in enumerate(lines):
            if f'const {handler_name} =' in line or f'const {handler_name}=' in line:
                handler_start = i
                break
        
        if handler_start == -1:
            print(f"    [INFO] Handler '{handler_name}' not found in TSX")
            return lines
        
        # Find the end of the handler
        handler_end = self._find_function_end(lines, handler_start)
        
        # Remove the old handler - the hook function with the same name is available from destructuring
        # We'll use handleSubmit(hookFunction) directly in onClick
        new_handler = [
            f"  // Handler '{handler_name}' is now provided by React Hook Form hook",
            f"  // Use {handle_submit_name}({handler_name}) in onClick handlers",
            ""
        ]
        
        # Replace old handler with comment
        lines = lines[:handler_start] + new_handler + lines[handler_end + 1:]
        
        # Update onClick to use React Hook Form handleSubmit (with correct hook variable)
        for i in range(len(lines)):
            # Find button with onClick={handler_name}
            if f'onClick={{{handler_name}}}' in lines[i] or f'onClick={{ {handler_name} }}' in lines[i]:
                # Replace with handleSubmit wrapper (using correct hook's handleSubmit)
                lines[i] = lines[i].replace(
                    f'onClick={{{handler_name}}}',
                    f'onClick={{{handle_submit_name}({handler_name})}}'
                ).replace(
                    f'onClick={{ {handler_name} }}',
                    f'onClick={{{handle_submit_name}({handler_name})}}'
                )
        
        print(f"    ✓ Wired {handler_name} with React Hook Form")

        return lines
    
    def _find_function_end(self, lines: List[str], start: int) -> int:
        """Find the end line of a function."""
        brace_count = 0
        started = False
        
        for i in range(start, min(start + 100, len(lines))):
            line = lines[i]
            for char in line:
                if char == '{':
                    brace_count += 1
                    started = True
                elif char == '}':
                    brace_count -= 1
            
            if started and brace_count == 0:
                return i
        
        return start + 20  # Fallback
    
    def _find_showNotification_definition(self, lines: List[str]) -> int:
        """Find the line where showNotification is defined."""
        for i, line in enumerate(lines):
            if 'const showNotification' in line or 'const showNotification =' in line:
                return i
        return -1
    
    def _find_hook_injection_point(self, lines: List[str]) -> int:
        """
        Find where to inject hook calls.
        Should be AFTER showNotification is defined and BEFORE any event handlers.
        """
        # First, find showNotification definition
        show_notif_line = self._find_showNotification_definition(lines)
        
        if show_notif_line == -1:
            # Fallback: look for useState declarations
            for i, line in enumerate(lines):
                if 'useState' in line:
                    return i + 1
            return -1
        
        # Find the end of showNotification function
        # It's usually a single-line or multi-line function
        brace_count = 0
        for i in range(show_notif_line, min(show_notif_line + 30, len(lines))):
            line = lines[i]
            for char in line:
                if char == '{':
                    brace_count += 1
                elif char == '}':
                    brace_count -= 1
            
            # If we've closed all braces and found a semicolon, we're done
            if brace_count == 0 and ';' in line:
                return i + 1
        
        # Fallback: return line after showNotification
        return show_notif_line + 2
    
    def _inject_hook_calls_at_component_level(self, lines: List[str]) -> List[str]:
        """
        Inject hook calls at component level (after showNotification, before handlers).
        This fixes the TS2448/TS2454 errors.
        """
        print("  - Injecting hook calls at component level...")
        
        # Find injection point
        injection_point = self._find_hook_injection_point(lines)
        
        if injection_point == -1:
            print("    [WARNING] Could not find hook injection point, skipping...")
            return lines
        
        # Collect all hooks that need to be called
        hook_calls = []
        hook_calls.append("")
        hook_calls.append("  // Auto-generated hook calls (at component level)")
        
        # Find all screen_mappings that have field_mappings OR handler_mappings
        # Each screen needs its hook called if it has any fields or handlers
        for screen in self.screen_mappings:
            story_id = screen.get('story_id', '')
            handler_mappings = screen.get('handler_mappings', [])
            field_mappings = screen.get('field_mappings', [])
            
            # Generate hook name using standard naming conventions
            tsx_screen_name = screen.get('tsx_screen_name', 'UnknownScreen')
            hook_name = self._generate_hook_name_from_screen(tsx_screen_name, story_id)
            
            # Create unique variable names per hook to avoid conflicts
            # Use standard naming for hook variable suffix
            screen_base = tsx_screen_name.replace('Screen', '').replace('screen', '')
            if not screen_base:
                screen_base = self._normalize_name(story_id.replace(' ', '').replace('User', '').replace('Story', ''))
            hook_var_suffix = screen_base
            
            # Extract handler function names
            handler_names = []
            for mapping in handler_mappings:
                    func_name = mapping.get('tsx_function_name', '')
                    if func_name:
                        handler_names.append(func_name)
                
            # Call hook if it has fields or handlers
            if field_mappings or handler_mappings:
                # Generate hook call with destructuring including React Hook Form methods
                # Use unique variable names to avoid conflicts between multiple hooks
                if handler_names:
                    destructured = ', '.join(handler_names)
                    hook_calls.append(f"  const {{ {destructured}, register: register{hook_var_suffix}, handleSubmit: handleSubmit{hook_var_suffix}, errors: errors{hook_var_suffix}, setError: setError{hook_var_suffix}, clearErrors: clearErrors{hook_var_suffix}, reset: reset{hook_var_suffix} }} = {hook_name}(showNotification);")
                else:
                    # Hook has fields but no handlers - still need register/errors
                    hook_calls.append(f"  const {{ register: register{hook_var_suffix}, handleSubmit: handleSubmit{hook_var_suffix}, errors: errors{hook_var_suffix}, setError: setError{hook_var_suffix}, clearErrors: clearErrors{hook_var_suffix}, reset: reset{hook_var_suffix} }} = {hook_name}(showNotification);")
        
        hook_calls.append("")
        
        # Insert hook calls at the injection point
        lines = lines[:injection_point] + hook_calls + lines[injection_point:]
        
        print(f"    ✓ Injected {len(hook_calls) - 3} hook call(s) at line {injection_point}")
        
        return lines
    
    def _add_api_data_loading(self, lines: List[str]) -> List[str]:
        """Add useEffect for loading data from APIs."""
        print("  - Adding API data loading...")
        
        # Find the component function start
        component_start = -1
        for i, line in enumerate(lines):
            if 'const ' in line and '= () =>' in line and 'Screen' not in line:
                # This is likely the main component
                if '{' in line or (i + 1 < len(lines) and '{' in lines[i + 1]):
                    component_start = i
                    break
        
        if component_start == -1:
            return lines
        
        # Find where to insert useEffect (after useState declarations)
        insert_point = component_start + 1
        for i in range(component_start + 1, min(component_start + 50, len(lines))):
            if 'useState' in lines[i]:
                insert_point = i + 1
        
        # Build useEffect for data loading
        useeffect_code = [
            "",
            "  // Load initial data from API",
            "  useEffect(() => {",
            "    const loadData = async () => {",
            "      try {",
        ]
        
        # Add API calls for main entities used in screens
        entities_to_load = set()
        for screen in self.screen_mappings:
            entity = screen.get('primary_entity', '')
            if entity:
                entities_to_load.add(entity)
        
        for entity in entities_to_load:
            service_name = f"{self._normalize_name(entity)}Service"
            # Assume there's a state variable for this entity
            var_name = f"{self._to_camel_case(entity)}Items"
            setter_name = f"set{self._normalize_name(entity)}Items"
            
            useeffect_code.append(f"        // const data = await {service_name}.getAll();")
            useeffect_code.append(f"        // {setter_name}(data);")
        
        useeffect_code.extend([
            "      } catch (error) {",
            "        console.error('Failed to load data:', error);",
            "      }",
            "    };",
            "    loadData();",
            "  }, []);",
            "",
        ])
        
        # Insert useEffect
        lines = lines[:insert_point] + useeffect_code + lines[insert_point:]
        
        # Make sure useEffect is imported
        for i, line in enumerate(lines):
            if "import React" in line and "useEffect" not in line:
                if "{ useState" in line:
                    lines[i] = line.replace("{ useState", "{ useState, useEffect")
                elif "{useState" in line:
                    lines[i] = line.replace("{useState", "{useState, useEffect")
                break
        
        return lines
    
    def _fix_typescript_types(self, content: str) -> str:
        """Fix TypeScript type issues with smart element type detection."""
        lines = content.splitlines()
        fixed_lines = []
        in_select = False
        
        for i, line in enumerate(lines):
            # Track if we're inside a <select> element
            if '<select' in line:
                in_select = True
            
            # Fix onChange handlers based on context
            if 'onChange=' in line:
                if in_select:
                    # Fix select elements - replace any Input type with Select type
                    line = re.sub(
                        r'onChange=\{\(e: React\.ChangeEvent<HTMLInputElement>\)',
                        r'onChange={(e: React.ChangeEvent<HTMLSelectElement>)',
                        line
                    )
                    # Also add types if missing
                    line = re.sub(
                        r'onChange=\{\(e\)\s*=>',
                        r'onChange={(e: React.ChangeEvent<HTMLSelectElement>) =>',
                        line
                    )
                elif '<input' in line or (i > 0 and '<input' in lines[i-1]):
                    # Fix input elements
                    line = re.sub(
                        r'onChange=\{\(e\)\s*=>',
                        r'onChange={(e: React.ChangeEvent<HTMLInputElement>) =>',
                        line
                    )
                elif '<textarea' in line or (i > 0 and '<textarea' in lines[i-1]):
                    # Fix textarea elements
                    line = re.sub(
                        r'onChange=\{\(e\)\s*=>',
                        r'onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>',
                        line
                    )
            
            # Track when we exit the select element
            if in_select and '/>' in line:
                in_select = False
            if in_select and '</select>' in line:
                in_select = False
            
            fixed_lines.append(line)
        
        content = '\n'.join(fixed_lines)
        
        # Add type annotations to common patterns
        replacements = [
            (r'showNotification\s*=\s*\((\w+),\s*(\w+)\)', r'showNotification = (\1: string, \2: string)'),
            (r'showModal\s*=\s*\((\w+)\)', r'showModal = (\1: string)'),
            (r'showScreen\s*=\s*\((\w+)\)', r'showScreen = (\1: string)'),
            (r'filter\(item =>', r'filter((item: any) =>'),
            (r'map\(\(item, index\)', r'map((item: any, index: number)'),
            (r'onClick=\{\(e\) =>', r'onClick={(e: React.MouseEvent) =>'),
        ]
        
        for pattern, replacement in replacements:
            content = re.sub(pattern, replacement, content)
        
        return content


def main():
    """Main entry point."""
    if len(sys.argv) < 6:
        print("Usage: python step_08_frontend_generator_claude_llm.py <wired_ui.json> <input_tsx> <input_dir> <output_dir> <tsx_metadata.json>")
        print("\nArguments:")
        print("  wired_ui.json     - Wiring plan generated by Step 07")
        print("  input_tsx         - Original TSX file to wire (can be same as in input_dir)")
        print("  input_dir         - Directory containing source files")
        print("  output_dir        - Directory to write generated output")
        print("  tsx_metadata.json - TSX metadata from Step 06 (for ID injection)")
        print("\nExample:")
        print("  python step_08_frontend_generator_claude_llm.py wired_ui.json ui_react_component.tsx . ./output tsx_metadata.json")
        sys.exit(1)
    
    wired_ui_path = Path(sys.argv[1])
    input_tsx_path = Path(sys.argv[2])
    input_dir = Path(sys.argv[3])
    output_dir = Path(sys.argv[4])
    tsx_metadata_path = Path(sys.argv[5])
    
    # Validate inputs
    if not wired_ui_path.exists():
        print(f"[ERROR] Wiring plan not found: {wired_ui_path}")
        sys.exit(1)
    
    if not input_tsx_path.exists():
        print(f"[ERROR] Input TSX file not found: {input_tsx_path}")
        sys.exit(1)
    
    if not input_dir.exists():
        print(f"[ERROR] Input directory not found: {input_dir}")
        sys.exit(1)
    
    if not tsx_metadata_path.exists():
        print(f"[WARNING] TSX metadata not found: {tsx_metadata_path}")
        print(f"[WARNING] ID injection will be skipped")
        tsx_metadata_path = None  # Set to None to handle gracefully
    
    print(f"--- Step 08: Frontend Code Generation ---")
    print(f"Wiring Plan: {wired_ui_path}")
    print(f"Input TSX: {input_tsx_path}")
    print(f"Input Dir: {input_dir}")
    print(f"Output Dir: {output_dir}")
    print(f"TSX Metadata: {tsx_metadata_path if tsx_metadata_path else 'None (ID injection disabled)'}")
    
    # Load wiring plan
    with open(wired_ui_path, 'r', encoding='utf-8') as f:
        wiring_plan = json.load(f)
    
    # Validate wiring plan format
    if 'screen_mappings' not in wiring_plan and 'stories' in wiring_plan:
        print("[WARNING] Detected OLD wiring plan format (stories[]). Expected NEW format (screen_mappings[]).")
        print("[WARNING] Please regenerate wiring plan using Step 06 and Step 07.")
        sys.exit(1)
    
    # Copy input TSX to input_dir if different location
    if input_tsx_path.parent != input_dir:
        import shutil
        dest_tsx = input_dir / input_tsx_path.name
        if not dest_tsx.exists():
            shutil.copy(input_tsx_path, dest_tsx)
            print(f"[INFO] Copied TSX to input directory: {dest_tsx}")
    
    # Generate code
    generator = FrontendCodeGenerator(
        wiring_plan=wiring_plan,
        input_dir=input_dir,
        output_dir=output_dir,
        tsx_metadata_path=tsx_metadata_path
    )
    
    generator.generate()
    
    print(f"\n{'='*60}")
    print(f"[SUCCESS] Frontend code generation complete!")
    print(f"{'='*60}")
    print(f"\nGenerated files in: {output_dir}")
    print(f"\nNext steps:")
    print(f"  1. cd {output_dir}")
    print(f"  2. npm install")
    print(f"  3. npm start")
    print(f"\nEnsure backend API is running at http://localhost:8000")


if __name__ == '__main__':
    main()
