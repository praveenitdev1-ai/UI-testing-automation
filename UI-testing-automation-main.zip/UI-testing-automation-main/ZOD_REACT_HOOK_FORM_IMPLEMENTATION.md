# Implementation Guide: Zod + React Hook Form Integration

## Overview

This guide provides step-by-step instructions to implement Zod schema generation and React Hook Form integration in `step_7c_frontend_generator_claude_llm.py`.

---

## Step 1: Add New Methods for Zod Schema Generation

### 1.1 Add `_generate_zod_schema_file()` Method

**Location**: After `_generate_types()` method (around line 230)

```python
def _generate_zod_schema_file(self, screen_mapping: Dict[str, Any]) -> str:
    """Generate Zod schema file for a screen."""
    story_id = screen_mapping['story_id']
    field_mappings = screen_mapping.get('field_mappings', [])
    
    schema_name = f"{self._normalize_name(story_id.replace(' ', ''))}FormSchema"
    
    schema_lines = [
        "// Auto-generated Zod schema",
        "import { z } from 'zod';",
        ""
    ]
    
    schema_lines.append(f"export const {schema_name} = z.object({{")
    
    for mapping in field_mappings:
        binding = mapping.get('config_binding', '')
        field_id = self._extract_column_from_binding(binding)
        
        if not field_id:
            field_id = mapping.get('config_field_id', '')
        
        if not field_id:
            continue
        
        validations = mapping.get('validations', [])
        error_messages = mapping.get('error_messages', {})
        
        # Build Zod field schema
        zod_field = self._build_zod_field_schema(field_id, validations, error_messages)
        schema_lines.append(f"  {field_id}: {zod_field},")
    
    schema_lines.append("});")
    schema_lines.append("")
    schema_lines.append(f"export type {schema_name}Type = z.infer<typeof {schema_name}>;")
    
    return '\n'.join(schema_lines), schema_name

def _build_zod_field_schema(
    self, 
    field_id: str, 
    validations: List[Dict], 
    error_messages: Dict[str, str]
) -> str:
    """Build Zod schema string for a single field."""
    if not validations:
        return "z.string().optional()"
    
    base_type = None
    refinements = []
    
    # Determine base type from validations
    for validation in validations:
        rule = validation.get('rule', '').lower()
        is_required = validation.get('required', False)
        
        # Determine TypeScript/Zod type
        if 'integer' in rule or 'number' in rule or 'positive' in rule:
            base_type = 'number'
        elif 'boolean' in rule:
            base_type = 'boolean'
        else:
            base_type = 'string'
    
    if not base_type:
        base_type = 'string'
    
    # Build base Zod schema
    if base_type == 'number':
        zod_schema = "z.number()"
    elif base_type == 'boolean':
        zod_schema = "z.boolean()"
    else:
        zod_schema = "z.string()"
    
    # Add validations as refinements
    for validation in validations:
        rule = validation.get('rule', '').lower()
        is_required = validation.get('required', False)
        default_error = validation.get('error_message', f'{field_id} is invalid')
        
        # Custom error message from config (prioritize)
        custom_error = error_messages.get(rule, error_messages.get('required', default_error))
        
        if is_required or 'required' in rule or 'must be present' in rule:
            if base_type == 'string':
                zod_schema += f'.min(1, {{ message: "{custom_error}" }})'
            # For number/boolean, required means non-null
            elif base_type == 'number':
                zod_schema += f'.refine((val) => val !== null && val !== undefined, {{ message: "{custom_error}" }})'
        
        if 'positive' in rule and 'integer' in rule:
            zod_schema += f'.int().positive({{ message: "{custom_error}" }})'
        elif 'integer' in rule and base_type == 'number':
            zod_schema += f'.int({{ message: "{custom_error}" }})'
        elif 'positive' in rule and base_type == 'number':
            zod_schema += f'.positive({{ message: "{custom_error}" }})'
        
        # Format validation (regex patterns)
        if 'format' in rule or 'regex' in rule or 'must be valid' in rule:
            # Extract pattern from rule if possible, otherwise use generic
            pattern = self._extract_regex_pattern(rule)
            if pattern:
                zod_schema += f'.regex({pattern}, {{ message: "{custom_error}" }})'
        
        # Custom business rule validations using .refine()
        if 'must be' in rule and "'" in rule:
            # Example: "must be 'Salvage' to start workflow"
            expected_value = rule.split("'")[1] if "'" in rule else None
            if expected_value:
                zod_schema += f'.refine((val) => val === "{expected_value}", {{ message: "{custom_error}" }})'
        
        if 'must be unique' in rule:
            # This requires async validation - handled in form submission
            pass
        
        if 'must exist in' in rule:
            # This requires async validation - handled in form submission
            pass
    
    # Make optional if not required
    if not any(v.get('required', False) or 'required' in v.get('rule', '').lower() for v in validations):
        zod_schema += '.optional()'
    
    return zod_schema

def _extract_regex_pattern(self, rule: str) -> Optional[str]:
    """Extract regex pattern from validation rule."""
    # Common patterns
    patterns = {
        'tracking number': r'/^[A-Z0-9]{8,12}$/',
        'email': r'/^[^\s@]+@[^\s@]+\.[^\s@]+$/',
        'phone': r'/^\+?[\d\s-()]{10,}$/',
        'url': r'/^https?:\/\/.+/',
    }
    
    rule_lower = rule.lower()
    for key, pattern in patterns.items():
        if key in rule_lower:
            return pattern
    
    return None
```

---

## Step 2: Modify Hook Generation to Use React Hook Form

### 2.1 Update `_generate_screen_hook()` Method

**Replace** the hook generation (lines 412-459) with:

```python
def _generate_screen_hook(self, screen_mapping: Dict[str, Any]):
    """Generate hook for a single screen."""
    story_id = screen_mapping['story_id']
    tsx_screen_name = screen_mapping['tsx_screen_name']
    primary_entity = screen_mapping.get('primary_entity', '')
    field_mappings = screen_mapping.get('field_mappings', [])
    handler_mappings = screen_mapping.get('handler_mappings', [])
    
    # Normalize names
    hook_name = f"use{self._normalize_name(story_id.replace(' ', ''))}Logic"
    entity_class = self._normalize_name(primary_entity)
    service_name = f"{entity_class}Service"
    schema_name = f"{self._normalize_name(story_id.replace(' ', ''))}FormSchema"
    
    # Generate Zod schema
    schema_content, schema_var_name = self._generate_zod_schema_file(screen_mapping)
    
    # Write schema file
    schema_file = self.output_dir / "src" / "schemas" / f"{schema_name}.ts"
    schema_file.parent.mkdir(parents=True, exist_ok=True)
    schema_file.write_text(schema_content, encoding='utf-8')
    print(f"  ✓ Generated {schema_name}.ts")
    
    # Generate handler code
    form_type_name = self._generate_screen_form_type_name(story_id)
    handler_code = self._build_handler_code(handler_mappings, service_name, entity_class, form_type_name)
    
    hook_content = f"""// Auto-generated hook for {story_id}
// Screen: {tsx_screen_name}
import {{ useState, useCallback }} from 'react';
import {{ useForm }} from 'react-hook-form';
import {{ zodResolver }} from '@hookform/resolvers/zod';
import {{ {schema_var_name}, {schema_var_name}Type }} from '../schemas/{schema_name}';
import {service_name} from '../services/{service_name}';
import {{ {entity_class}, {entity_class}Create }} from '../types/entities';

interface UseLogicResult {{
  loading: boolean;
  register: any; // React Hook Form register function
  handleSubmit: (onSubmit: (data: {schema_var_name}Type) => void) => (e?: React.BaseSyntheticEvent) => Promise<void>;
  errors: any; // React Hook Form errors
  setError: (name: string, error: {{ type: string; message: string }}) => void;
  clearErrors: (name?: string | string[]) => void;
  {self._build_handler_type_signatures(handler_mappings)}
}}

export const {hook_name} = (
  showNotification: (message: string, type: 'success' | 'danger' | 'warning') => void
): UseLogicResult => {{
  const [loading, setLoading] = useState(false);

  const {{
    register,
    handleSubmit: hookFormHandleSubmit,
    formState: {{ errors }},
    setError,
    clearErrors,
    reset
  }} = useForm<{schema_var_name}Type>({{
    resolver: zodResolver({schema_var_name}),
    mode: 'onBlur', // Validate on blur
    reValidateMode: 'onChange' // Re-validate on change
  }});

  {handler_code}

  return {{
    loading,
    register,
    handleSubmit: hookFormHandleSubmit,
    errors,
    setError,
    clearErrors,
    {self._build_handler_return_list(handler_mappings)}
  }};
}};

export default {hook_name};
"""
    
    hook_file = self.hooks_dir / f"{hook_name}.ts"
    hook_file.write_text(hook_content, encoding='utf-8')
    print(f"  ✓ Generated {hook_name}.ts")
```

---

## Step 3: Update Handler Generation for React Hook Form

### 3.1 Modify `_build_create_handler()` Method

**Replace** (lines 589-629) with:

```python
def _build_create_handler(
    self, 
    func_name: str, 
    service_name: str, 
    entity_class: str,
    form_type_name: str
) -> str:
    """Build create/POST handler using React Hook Form."""
    return f"""  /**
   * Handle create operation with React Hook Form validation
   */
  const {func_name} = useCallback(async (formData: {form_type_name}): Promise<{entity_class} | null> => {{
    // Validation is handled by Zod + React Hook Form
    // This function is called after validation passes
    
    setLoading(true);

    try {{
      // Convert formData to API format (entity type)
      const apiData = formData as any;  // Type assertion for API call
      const result = await {service_name}.create(apiData);
      showNotification('Item created successfully', 'success');
      reset(); // Reset form after successful submission
      return result;
    }} catch (error: any) {{
      // Handle API validation errors
      if (error.response?.data?.detail) {{
        const detail = error.response.data.detail;
        
        // If detail is an object with field errors
        if (typeof detail === 'object' && !Array.isArray(detail)) {{
          Object.keys(detail).forEach((field) => {{
            setError(field, {{
              type: 'server',
              message: Array.isArray(detail[field]) ? detail[field][0] : detail[field]
            }});
          }});
          showNotification('Please fix the errors below', 'danger');
        }} else {{
          const message = Array.isArray(detail) ? detail[0] : detail;
          showNotification(`Operation failed: ${{message}}`, 'danger');
        }}
      }} else {{
        showNotification(`Operation failed: ${{error.message}}`, 'danger');
      }}
      return null;
    }} finally {{
      setLoading(false);
    }}
  }}, [reset, setError, showNotification]);"""
```

---

## Step 4: Update Infrastructure Generation

### 4.1 Modify `_generate_infrastructure()` Method

**Update** `package.json` generation (lines 760-785) to include:

```python
pkg = {
    "name": self._to_camel_case(self.app_name),
    "version": "1.0.0",
    "private": True,
    "dependencies": {
        "react": "^18.2.0",
        "react-dom": "^18.2.0",
        "react-scripts": "5.0.1",
        "axios": "^1.6.0",
        "typescript": "^4.9.5",
        "react-hook-form": "^7.48.0",  # ADD THIS
        "zod": "^3.22.0",               # ADD THIS
        "@hookform/resolvers": "^3.3.0" # ADD THIS
    },
    # ... rest
}
```

---

## Step 5: Update TSX Processing to Use React Hook Form

### 5.1 Modify `_wire_handlers()` to Use React Hook Form

**Update** `_wire_single_handler()` (lines 1098-1182) to:

```python
def _wire_single_handler(
    self, 
    lines: List[str], 
    handler_name: str,
    screen: Dict
) -> List[str]:
    """Wire a single handler function using React Hook Form."""
    story_id = screen['story_id']
    hook_name = f"use{self._normalize_name(story_id.replace(' ', ''))}Logic"
    field_mappings = screen.get('field_mappings', [])
    
    # Find the handler function
    handler_start = -1
    for i, line in enumerate(lines):
        if f'const {handler_name} =' in line or f'const {handler_name}=' in line:
            handler_start = i
            break
    
    if handler_start == -1:
        print(f"    [INFO] Handler '{handler_name}' not found in TSX")
        return lines
    
    # Find the end of the handler
    handler_end = self._find_function_end(lines, handler_start)
    
    # Build new handler that uses React Hook Form
    new_handler = [
        f"  const {handler_name} = async (formData: any) => {{",
        f"    // Validation handled by React Hook Form + Zod",
        f"    // This is called by handleSubmit wrapper",
        f"    const result = await {handler_name}Hook(formData);",
        f"    if (result) {{",
        f"      // Success handled in hook",
        f"    }}",
        f"  }};",
        ""
    ]
    
    # Replace old handler
    lines = lines[:handler_start] + new_handler + lines[handler_end + 1:]
    
    # Update onClick to use React Hook Form handleSubmit
    for i in range(len(lines)):
        # Find button with onClick={handler_name}
        if f'onClick={{{handler_name}}}' in lines[i] or f'onClick={{ {handler_name} }}' in lines[i]:
            # Replace with handleSubmit wrapper
            lines[i] = lines[i].replace(
                f'onClick={{{handler_name}}}',
                f'onClick={{handleSubmit({handler_name})}}'
            ).replace(
                f'onClick={{ {handler_name} }}',
                f'onClick={{handleSubmit({handler_name})}}'
            )
    
    # Update input fields to use React Hook Form register
    for mapping in field_mappings:
        tsx_id = mapping.get('tsx_id', '')
        binding = mapping.get('config_binding', '')
        field_id = self._extract_column_from_binding(binding) or mapping.get('config_field_id', '')
        
        # Find input/select/textarea with this id
        for i, line in enumerate(lines):
            if f'id="{tsx_id}"' in line or f"id='{tsx_id}'" in line:
                # Add {...register('field_id')}
                if '<input' in line:
                    # Add register after existing props
                    if 'type=' in line:
                        lines[i] = line.replace(
                            f'id="{tsx_id}"',
                            f'id="{tsx_id}" {...register("{field_id}")}'
                        )
                    else:
                        lines[i] = line.replace(
                            f'id="{tsx_id}"',
                            f'id="{tsx_id}" type="text" {...register("{field_id}")}'
                        )
                
                # Add error display after the input
                error_display = f"""
                {{errors.{field_id} && (
                  <span className="error-message">{{errors.{field_id}.message}}</span>
                )}}"""
                
                # Insert error display after this line
                lines.insert(i + 1, error_display)
                break
    
    print(f"    ✓ Wired {handler_name} with React Hook Form")
    
    return lines
```

---

## Step 6: Add Hook Injection for React Hook Form

### 6.1 Update `_inject_hook_calls_at_component_level()`

**Modify** (lines 1243-1290) to destructure React Hook Form methods:

```python
hook_calls.append(f"  const {{ {destructured}, register, handleSubmit, errors }} = {hook_name}(showNotification);")
```

---

## Testing Checklist

After implementation, test:

- [ ] Zod schemas are generated correctly
- [ ] React Hook Form integration works
- [ ] Validation errors display correctly
- [ ] Form submission works
- [ ] Custom error messages from config appear
- [ ] Required field validation works
- [ ] Format validation (regex) works
- [ ] Number/integer validation works
- [ ] API errors map to form errors

---

## Migration Notes

1. **Existing Code**: Generated apps will need to be regenerated
2. **Backward Compatibility**: Old validation hooks will be replaced
3. **Breaking Changes**: Form handlers must use `handleSubmit` wrapper
4. **Dependencies**: Ensure `npm install` includes new packages

---

*Implementation Guide v1.0*
