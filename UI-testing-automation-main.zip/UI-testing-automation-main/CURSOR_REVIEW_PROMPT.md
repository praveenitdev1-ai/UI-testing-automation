# Cursor Prompt: Senior AI Architect Code Review

## Task
As a senior AI architect, review the attached codebase that automates React application generation from design team components.

## System Flow
1. `application_config.json` is created from user stories (✅ working)
2. Design team provides React TSX component
3. **Step 7a** (`step_7a_tsx_extractor.py`): Extracts fields/handlers from TSX, preserves look & feel
4. **Step 7b** (`step_7b_frontend_wiring_claude_llm.py`): Matches TSX fields to config fields, creates wiring plan
5. **Step 7c** (`step_7c_frontend_generator_claude_llm.py`): Generates React app with validation & API wiring

## Critical Review Areas

### ⚠️ CRITICAL GAP: Zod & React Hook Form Implementation
**Requirement**: "implement the zod and react hook form based validation"

**Current State**: 
- `_build_validation_code()` (lines 465-507) generates plain JavaScript validation functions
- **NO Zod schemas are generated**
- **NO React Hook Form integration**
- Validation is manual `if` statements, not declarative schemas

**Action Required**: 
- Generate Zod schemas from `validation_rules` in `application_config.json`
- Integrate `@hookform/resolvers/zod` with `useForm` from `react-hook-form`
- Replace manual validation with Zod schema validation
- Ensure custom error messages from config are used

### 1. Field Matching & Mismatch Handling
- Review `_find_best_field_match()` in Step 7b (lines 372-510)
- Verify 9-tier confidence system handles edge cases
- **Question**: What happens when TSX field "Item Description" doesn't match config "item_desc"? Is it preserved or dropped?
- Check `unmapped_elements` tracking - are mismatched fields handled gracefully?

### 2. Look & Feel Preservation
- Verify Step 7a does NOT modify CSS classes, inline styles, or layout
- Check that only IDs are injected (if missing), not structural changes
- Ensure generated code maintains exact visual appearance

### 3. React Best Practices
- Review generated hooks for proper `useCallback` usage
- Check TypeScript typing (minimize `any` types)
- Verify modular folder structure: `services/`, `hooks/`, `types/`
- Ensure proper error boundaries and loading states

### 4. API Integration
- Review service layer generation (axios-based)
- Check authentication token handling
- Verify error handling and user-friendly error messages
- Ensure form data correctly transforms TSX → API format

### 5. Non-React Input Handling
- **Question**: If design team provides vanilla HTML/JS, does generator convert to React?
- Verify class components → functional components conversion
- Check proper JSX syntax generation

### 6. Validation Coverage
- Are ALL validation rules from config converted to validation code?
- Are custom error messages preserved?
- Is validation triggered on submit AND on blur?

## Specific Code Sections to Review

### Step 7a (`step_7a_tsx_extractor.py`)
- `_generate_field_id()` (471-510): Deterministic ID generation
- `_extract_fields_from_content()` (201-449): Field extraction logic
- `_find_label_for_element()` (687-734): Label association

### Step 7b (`step_7b_frontend_wiring_claude_llm.py`)
- `_find_best_field_match()` (372-510): Matching algorithm
- `_build_screen_to_story_map()` (246-270): Screen-to-story mapping
- `_build_ac_coverage_with_mapping()` (779-863): Acceptance criteria tracking

### Step 7c (`step_7c_frontend_generator_claude_llm.py`)
- `_build_validation_code()` (465-507): **NEEDS ZOD/REACT-HOOK-FORM**
- `_generate_screen_hook()` (383-463): Hook generation
- `_inject_hook_calls_at_component_level()` (1243-1290): Hook injection

## Expected Output

Provide:
1. **Executive Summary**: Critical issues + priority recommendations
2. **Detailed Findings**: Status (✅/⚠️/❌) for each area with code references
3. **Code Improvements**: Specific changes needed, especially Zod/React Hook Form integration
4. **Testing Recommendations**: Edge cases and test scenarios

## Priority Actions
1. **HIGH**: Implement Zod schema generation and React Hook Form integration
2. **HIGH**: Verify field mismatch handling preserves functionality
3. **MEDIUM**: Review TypeScript typing and remove unnecessary `any` types
4. **MEDIUM**: Add comprehensive error handling throughout pipeline
5. **LOW**: Improve logging and documentation

---

**Focus**: Ensure generated React app is production-ready, follows best practices, and properly implements Zod/React Hook Form validation as required.

