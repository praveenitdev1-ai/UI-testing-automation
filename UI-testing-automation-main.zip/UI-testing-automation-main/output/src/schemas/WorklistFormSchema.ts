// Auto-generated Zod schema
import { z } from 'zod';

export const WorklistFormSchema = z.object({
  item_id: z.string().min(1, { message: "Item ID is required" }),
  tracking_number: z.string().min(1, { message: "Invalid tracking number - please verify and try again" }), //.regex(/^[A-Z0-9]{8,12}$/, { message: "Invalid tracking number - please verify and try again" }),
  description: z.string().min(1, { message: "Item Description is required" }),
  stage: z.string().optional(),
  quantity: z.coerce.number().int({ message: "Quantity must be a positive integer" }).positive({ message: "Quantity must be a positive integer" }).refine((val) => val !== null && val !== undefined, { message: "Quantity is required" }),
  location_id: z.string().min(1, { message: "Location is required" }),
  disposition: z.string().min(1, { message: "Disposition Type is required" }),
  value: z.string().optional(),
  vendor_id: z.string().min(1, { message: "Vendor Name is required" }),
});

export type WorklistFormSchemaType = z.infer<typeof WorklistFormSchema>;