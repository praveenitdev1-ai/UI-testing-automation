// Auto-generated Zod schema
import { z } from 'zod';

export const SalvageFormSchema = z.object({
  nsi_id: z.string().min(1, { message: "NSI ID is required" }),
  item_id: z.string().min(1, { message: "Item ID is required" }),
  disposition: z.string().min(1, { message: "Only items with Salvage disposition can start this workflow" }).refine((val) => val === "salvage", { message: "Only items with Salvage disposition can start this workflow" }),
  status: z.string().min(1, { message: "Item must be Approved to start workflow" }).refine((val) => val === "approved", { message: "Item must be Approved to start workflow" }),
});

export type SalvageFormSchemaType = z.infer<typeof SalvageFormSchema>;