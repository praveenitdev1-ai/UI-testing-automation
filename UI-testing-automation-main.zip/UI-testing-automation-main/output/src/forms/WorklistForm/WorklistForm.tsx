// Enterprise-ready form component
// One form = one hook = one Zod schema
import React from 'react';
import { useWorklist } from '../../hooks/useWorklist';
import { FormInput } from '../../components/FormInput/FormInput';
import { FormSelect } from '../../components/FormSelect/FormSelect';
import { useNotification } from '../../components/Notification/Notification';
import './WorklistForm.css';

interface WorklistFormProps {
  onSubmitSuccess?: () => void;
}

export const WorklistForm: React.FC<WorklistFormProps> = ({ onSubmitSuccess }) => {
  const { showNotification } = useNotification();
  const {
    register: registerUserstory1,
    handleSubmit: handleSubmitUserstory1,
    errors: errorsUserstory1,
    loading,
    addToWorklist
  } = useWorklist(showNotification);

  const onSubmit = handleSubmitUserstory1(async (formData) => {
    try {
      await addToWorklist(formData);
      onSubmitSuccess?.();
    } catch (error) {
      // Error handling done in hook
    }
  });

  return (
    <form onSubmit={onSubmit} className="form-container">
      <h3 className="form-title">User Story 1</h3>
      <div className="form-grid">
        <FormInput
          id="item_id"
          label="Item ID"
          type="text"
          register={registerUserstory1}
          fieldName="item_id"
          error={errorsUserstory1.item_id}
          placeholder="Enter item id"
        />
        <FormInput
          id="tracking_number"
          label="POS Tracking Number"
          type="text"
          register={registerUserstory1}
          fieldName="tracking_number"
          error={errorsUserstory1.tracking_number}
          placeholder="Enter pos tracking number"
        />
        <FormInput
          id="description"
          label="Item Description"
          type="text"
          register={registerUserstory1}
          fieldName="description"
          error={errorsUserstory1.description}
          placeholder="Enter item description"
        />
        <FormInput
          id="department_number"
          label="Department Number"
          type="text"
          register={registerUserstory1}
          fieldName="stage"
          error={errorsUserstory1.stage}
          placeholder="Enter department number"
        />
        <FormInput
          id="quantity"
          label="Quantity"
          type="number"
          register={registerUserstory1}
          fieldName="quantity"
          error={errorsUserstory1.quantity}
          placeholder="Enter quantity"
          valueAsNumber={true}
        />
        <FormInput
          id="location"
          label="Location"
          type="text"
          register={registerUserstory1}
          fieldName="location_id"
          error={errorsUserstory1.location_id}
          placeholder="Enter location"
        />
        <FormInput
          id="disposition_type"
          label="Disposition Type"
          type="text"
          register={registerUserstory1}
          fieldName="disposition"
          error={errorsUserstory1.disposition}
          placeholder="Enter disposition type"
        />
        <FormInput
          id="sell_price"
          label="Sell Price"
          type="text"
          register={registerUserstory1}
          fieldName="value"
          error={errorsUserstory1.value}
          placeholder="Enter sell price"
        />
        <FormInput
          id="on_hand_inventory"
          label="On Hand Inventory"
          type="text"
          register={registerUserstory1}
          fieldName="quantity"
          error={errorsUserstory1.quantity}
          placeholder="Enter on hand inventory"
        />
        <FormInput
          id="vendor_name"
          label="Vendor Name"
          type="text"
          register={registerUserstory1}
          fieldName="vendor_id"
          error={errorsUserstory1.vendor_id}
          placeholder="Enter vendor name"
        />
      </div>
      <button type="submit" className="btn btn-primary" disabled={loading}>
        {loading ? 'Submitting...' : 'Submit'}
      </button>
    </form>
  );
};

export default WorklistForm;
