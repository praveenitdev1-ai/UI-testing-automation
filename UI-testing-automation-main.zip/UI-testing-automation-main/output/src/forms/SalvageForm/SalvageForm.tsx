// Enterprise-ready form component
// One form = one hook = one Zod schema
import React from 'react';
import { useSalvage } from '../../hooks/useSalvage';
import { FormInput } from '../../components/FormInput/FormInput';
import { FormSelect } from '../../components/FormSelect/FormSelect';
import { useNotification } from '../../components/Notification/Notification';
import './SalvageForm.css';

interface SalvageFormProps {
  onSubmitSuccess?: () => void;
}

export const SalvageForm: React.FC<SalvageFormProps> = ({ onSubmitSuccess }) => {
  const { showNotification } = useNotification();
  const {
    register: registerUserstory2,
    handleSubmit: handleSubmitUserstory2,
    errors: errorsUserstory2,
    loading,
    processSubmit
  } = useSalvage(showNotification);

  const onSubmit = handleSubmitUserstory2(async (formData) => {
    try {
      await processSubmit(formData);
      onSubmitSuccess?.();
    } catch (error) {
      // Error handling done in hook
    }
  });

  return (
    <form onSubmit={onSubmit} className="form-container">
      <h3 className="form-title">User Story 2</h3>
      <div className="form-grid">
        <FormInput
          id="returnCenterNumber"
          label="NSI ID"
          type="text"
          register={registerUserstory2}
          fieldName="nsi_id"
          error={errorsUserstory2.nsi_id}
          placeholder="Enter nsi id"
        />
        <FormInput
          id="salvage_itemId"
          label="Item ID"
          type="text"
          register={registerUserstory2}
          fieldName="item_id"
          error={errorsUserstory2.item_id}
          placeholder="Enter item id"
        />
        <FormInput
          id="salvage_disposition"
          label="Disposition"
          type="text"
          register={registerUserstory2}
          fieldName="disposition"
          error={errorsUserstory2.disposition}
          placeholder="Enter disposition"
        />
        <FormInput
          id="salvage_status"
          label="Status"
          type="text"
          register={registerUserstory2}
          fieldName="status"
          error={errorsUserstory2.status}
          placeholder="Enter status"
        />
      </div>
      <button type="submit" className="btn btn-primary" disabled={loading}>
        {loading ? 'Submitting...' : 'Submit'}
      </button>
    </form>
  );
};

export default SalvageForm;
