// Reusable FormSelect component
// Enterprise-ready: Proper enum handling, no inline styles
import React from 'react';
import { UseFormRegister, FieldError } from 'react-hook-form';
import { ErrorText } from '../ErrorText/ErrorText';

interface FormSelectProps {
  id: string;
  label: string;
  register: UseFormRegister<any>;
  fieldName: string;
  error?: FieldError;
  options: Array<{ value: string; label: string }>;
  placeholder?: string;
  className?: string;
}

export const FormSelect: React.FC<FormSelectProps> = ({
  id,
  label,
  register,
  fieldName,
  error,
  options,
  placeholder,
  className = ''
}) => {
  const hasError = !!error;
  
  return (
    <div className={`form-field ${className}`}>
      <label htmlFor={id} className="form-label">
        {label}
      </label>
      <select
        id={id}
        {...register(fieldName)}
        className={`form-select ${hasError ? 'form-select-error' : ''}`}
        aria-invalid={hasError}
        aria-describedby={hasError ? `${id}-error` : undefined}
      >
        {placeholder && (
          <option value="">{placeholder}</option>
        )}
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {hasError && (
        <ErrorText id={`${id}-error`} message={error.message || 'Invalid value'} />
      )}
    </div>
  );
};

export default FormSelect;
