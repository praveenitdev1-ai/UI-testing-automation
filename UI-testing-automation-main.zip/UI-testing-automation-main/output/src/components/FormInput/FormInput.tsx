// Reusable FormInput component
// Enterprise-ready: No inline styles, proper error handling
import React from 'react';
import { UseFormRegister, FieldError } from 'react-hook-form';
import { ErrorText } from '../ErrorText/ErrorText';

interface FormInputProps {
  id: string;
  label: string;
  type?: 'text' | 'number' | 'email' | 'password';
  register: UseFormRegister<any>;
  fieldName: string;
  error?: FieldError;
  placeholder?: string;
  valueAsNumber?: boolean;
  className?: string;
}

export const FormInput: React.FC<FormInputProps> = ({
  id,
  label,
  type = 'text',
  register,
  fieldName,
  error,
  placeholder,
  valueAsNumber = false,
  className = ''
}) => {
  const hasError = !!error;
  
  return (
    <div className={`form-field ${className}`}>
      <label htmlFor={id} className="form-label">
        {label}
      </label>
      <input
        id={id}
        type={type}
        {...register(fieldName, { valueAsNumber })}
        className={`form-input ${hasError ? 'form-input-error' : ''}`}
        placeholder={placeholder}
        aria-invalid={hasError}
        aria-describedby={hasError ? `${id}-error` : undefined}
      />
      
      {hasError && (
        <ErrorText id={`${id}-error`} message={error.message || 'Invalid value'} />
      )}
    </div>
  );
};

export default FormInput;
