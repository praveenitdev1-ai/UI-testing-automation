// Centralized Notification component
// Enterprise-ready: Single source of truth for notifications
import React, { useState, useCallback, useEffect } from 'react';
import './Notification.css';

export type NotificationType = 'success' | 'danger' | 'warning' | 'info';

interface Notification {
  id: string;
  message: string;
  type: NotificationType;
}

interface NotificationContextValue {
  showNotification: (message: string, type: NotificationType) => void;
}

export const NotificationContext = React.createContext<NotificationContextValue | null>(null);

export const useNotification = (): NotificationContextValue => {
  const context = React.useContext(NotificationContext);
  if (!context) {
    // Fallback: Create a default implementation when used outside provider
    console.warn('useNotification used outside NotificationProvider, using console fallback');
    return {
      showNotification: (message: string, type: NotificationType) => {
        console.log(`[${type.toUpperCase()}] ${message}`);
      }
    };
  }
  return context;
};

interface NotificationProviderProps {
  children: React.ReactNode;
}

export const NotificationProvider: React.FC<NotificationProviderProps> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const showNotification = useCallback((message: string, type: NotificationType) => {
    const id = Date.now().toString();
    setNotifications((prev) => [...prev, { id, message, type }]);

    // Auto-remove after 5 seconds
    setTimeout(() => {
      setNotifications((prev) => prev.filter((n) => n.id !== id));
    }, 5000);
  }, []);

  const removeNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  return (
    <NotificationContext.Provider value={{ showNotification }}>
      {children}
      <div className="notification-container">
        {notifications.map((notification) => (
          <div
            key={notification.id}
            className={`notification notification-${notification.type}`}
            role="alert"
          >
            <span className="notification-message">{notification.message}</span>
            <button
              type="button"
              className="notification-close"
              onClick={() => removeNotification(notification.id)}
              aria-label="Close notification"
            >
              ×
            </button>
          </div>
        ))}
      </div>
    </NotificationContext.Provider>
  );
};

export default NotificationProvider;
