// Reusable ErrorText component
// Enterprise-ready: Accessible, styled consistently
import React from 'react';

interface ErrorTextProps {
  id?: string;
  message: string;
  className?: string;
}

export const ErrorText: React.FC<ErrorTextProps> = ({
  id,
  message,
  className = ''
}) => {
  return (
    <span
      id={id}
      className={`error-text ${className}`}
      role="alert"
      aria-live="polite"
    >
      {message}
    </span>
  );
};

export default ErrorText;
