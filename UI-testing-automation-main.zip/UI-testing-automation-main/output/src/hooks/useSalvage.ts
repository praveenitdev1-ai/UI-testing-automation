// Auto-generated hook for User Story 2
// Screen: SalvageScreen
// Uses React Hook Form + Zod for validation
import { useState, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { SalvageFormSchema, SalvageFormSchemaType } from '../schemas/SalvageFormSchema';
import NsiItemsService from '../services/NsiItemsService';
import { NsiItems, NsiItemsCreate } from '../types/entities';

interface UseLogicResult {
  loading: boolean;
  register: ReturnType<typeof useForm<SalvageFormSchemaType>>['register'];
  handleSubmit: ReturnType<typeof useForm<SalvageFormSchemaType>>['handleSubmit'];
  watch: ReturnType<typeof useForm<SalvageFormSchemaType>>['watch'];
  errors: ReturnType<typeof useForm<SalvageFormSchemaType>>['formState']['errors'];
  setError: ReturnType<typeof useForm<SalvageFormSchemaType>>['setError'];
  clearErrors: ReturnType<typeof useForm<SalvageFormSchemaType>>['clearErrors'];
  reset: ReturnType<typeof useForm<SalvageFormSchemaType>>['reset'];
  processSubmit: (formData: any) => Promise<any>;
}

export const useSalvage = (
  showNotification: (message: string, type: 'success' | 'danger' | 'warning') => void
): UseLogicResult => {
  const [loading, setLoading] = useState(false);

  // Calculate default values for form
  const getDefaultValues = (): Partial<SalvageFormSchemaType> => {
    return {};
  };

  const {
    register,
    handleSubmit: hookFormHandleSubmit,
    formState: { errors },
    setError,
    clearErrors,
    reset,
    watch
  } = useForm<SalvageFormSchemaType>({
    resolver: zodResolver(SalvageFormSchema),
    mode: 'onBlur', // Validate on blur - shows errors when user leaves field
    reValidateMode: 'onChange', // Re-validate on change after initial error
    criteriaMode: 'all', // Show all validation errors, not just the first one
    defaultValues: getDefaultValues(), // Use defaultValues instead of useState
    shouldFocusError: true // Focus first error field after validation fails
  });

    /**
   * Handle form submission with React Hook Form validation
   * Validation is handled by Zod + React Hook Form before this function is called
   */
  const processSubmit = useCallback(async (formData: SalvageFormSchemaType): Promise<NsiItems | null> => {
    setLoading(true);

    try {
      // Generate defaults (like tracking number) inside submit handler
      
            // No defaults to generate
      
      const apiData = formData as any;  // Type assertion for API call
      const result = await NsiItemsService.create(apiData);
      showNotification('Operation successful', 'success');
      reset(); // Reset form after successful submission
      return result;
    } catch (error: any) {
      // Handle API validation errors
      if (error.response?.data?.detail) {
        const detail = error.response.data.detail;
        
        if (typeof detail === 'object' && !Array.isArray(detail)) {
          Object.keys(detail).forEach((field) => {
            setError(field as any, {
              type: 'server',
              message: Array.isArray(detail[field]) ? detail[field][0] : detail[field]
            });
          });
          showNotification('Please fix the errors below', 'danger');
        } else {
          const message = Array.isArray(detail) ? detail[0] : detail;
      showNotification(`Operation failed: ${message}`, 'danger');
        }
      } else {
        showNotification(`Operation failed: ${error.message}`, 'danger');
      }
      return null;
    } finally {
      setLoading(false);
    }
  }, [reset, setError, showNotification]);

  return {
    loading,
    register,
    handleSubmit: hookFormHandleSubmit,
    watch,
    errors,
    setError,
    clearErrors,
    reset,
    processSubmit
  };
};

export default useSalvage;
