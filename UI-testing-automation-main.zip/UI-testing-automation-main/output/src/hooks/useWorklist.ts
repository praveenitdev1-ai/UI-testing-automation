// Auto-generated hook for User Story 1
// Screen: WorklistScreen
// Uses React Hook Form + Zod for validation
import { useState, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { WorklistFormSchema, WorklistFormSchemaType } from '../schemas/WorklistFormSchema';
import InventoryService from '../services/InventoryService';
import { Inventory, InventoryCreate } from '../types/entities';

interface UseLogicResult {
  loading: boolean;
  register: ReturnType<typeof useForm<WorklistFormSchemaType>>['register'];
  handleSubmit: ReturnType<typeof useForm<WorklistFormSchemaType>>['handleSubmit'];
  watch: ReturnType<typeof useForm<WorklistFormSchemaType>>['watch'];
  errors: ReturnType<typeof useForm<WorklistFormSchemaType>>['formState']['errors'];
  setError: ReturnType<typeof useForm<WorklistFormSchemaType>>['setError'];
  clearErrors: ReturnType<typeof useForm<WorklistFormSchemaType>>['clearErrors'];
  reset: ReturnType<typeof useForm<WorklistFormSchemaType>>['reset'];
  addToWorklist: (formData: any) => Promise<any>;
}

export const useWorklist = (
  showNotification: (message: string, type: 'success' | 'danger' | 'warning') => void
): UseLogicResult => {
  const [loading, setLoading] = useState(false);

  // Calculate default values for form
  const getDefaultValues = (): Partial<WorklistFormSchemaType> => {
    return {};
  };

  const {
    register,
    handleSubmit: hookFormHandleSubmit,
    formState: { errors },
    setError,
    clearErrors,
    reset,
    watch
  } = useForm<WorklistFormSchemaType>({
    resolver: zodResolver(WorklistFormSchema),
    mode: 'onBlur', // Validate on blur - shows errors when user leaves field
    reValidateMode: 'onChange', // Re-validate on change after initial error
    criteriaMode: 'all', // Show all validation errors, not just the first one
    defaultValues: getDefaultValues(), // Use defaultValues instead of useState
    shouldFocusError: true // Focus first error field after validation fails
  });

    /**
   * Handle create operation with React Hook Form validation
   * Validation is handled by Zod + React Hook Form before this function is called
   */
  const addToWorklist = useCallback(async (formData: WorklistFormSchemaType): Promise<Inventory | null> => {
    setLoading(true);

    try {
      // Generate defaults (like tracking number) inside submit handler
            // Auto-generate tracking number if blank
      if (!formData.tracking_number || formData.tracking_number.trim() === '') {
        formData.tracking_number = 'TRK' + Date.now().toString().slice(-8).toUpperCase();
      }
      
      // Convert formData to API format (entity type)
      const apiData = formData as any;  // Type assertion for API call
      const result = await InventoryService.create(apiData);
      showNotification('Item created successfully', 'success');
      reset(); // Reset form after successful submission
      return result;
    } catch (error: any) {
      // Handle API validation errors
      if (error.response?.data?.detail) {
        const detail = error.response.data.detail;
        
        // If detail is an object with field errors
        if (typeof detail === 'object' && !Array.isArray(detail)) {
          Object.keys(detail).forEach((field) => {
            setError(field as any, {
              type: 'server',
              message: Array.isArray(detail[field]) ? detail[field][0] : detail[field]
            });
          });
          showNotification('Please fix the errors below', 'danger');
        } else {
          const message = Array.isArray(detail) ? detail[0] : detail;
      showNotification(`Operation failed: ${message}`, 'danger');
        }
      } else {
        showNotification(`Operation failed: ${error.message}`, 'danger');
      }
      return null;
    } finally {
      setLoading(false);
    }
  }, [reset, setError, showNotification]);

  return {
    loading,
    register,
    handleSubmit: hookFormHandleSubmit,
    watch,
    errors,
    setError,
    clearErrors,
    reset,
    addToWorklist
  };
};

export default useWorklist;
