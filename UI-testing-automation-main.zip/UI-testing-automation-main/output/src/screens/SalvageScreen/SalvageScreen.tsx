// Screen component: SalvageScreen
// Extracted from main TSX for better maintainability
import React from 'react';
import { useSalvage } from '../../hooks/useSalvage';
import { SalvageForm } from '../../forms/SalvageForm/SalvageForm';
import { useNotification } from '../../components/Notification/Notification';
import './SalvageScreen.css';

interface SalvageScreenProps {
  // Add screen-specific props here
}

export const SalvageScreen: React.FC<SalvageScreenProps> = () => {
  const { showNotification } = useNotification();
  const { /* Add hook destructuring here if needed */ } = useSalvage(showNotification);
  
  return (
    <div className="salvagescreen">
      <div className="screen-header">
        <h1>Salvage</h1>
      </div>
      
      <div className="screen-content">
        {/* Screen content will be wired from main TSX */}
        {/* TODO: Extract screen JSX content from main TSX file */}
        <SalvageForm />
      </div>
    </div>
  );
};

export default SalvageScreen;
