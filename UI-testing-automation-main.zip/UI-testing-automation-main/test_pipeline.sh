#!/bin/bash

# Quick test script for the frontend generation pipeline

set -e  # Exit on error

echo "=========================================="
echo "Frontend Generation Pipeline Test"
echo "=========================================="
echo ""

# Step 1: Extract TSX Metadata
echo "=== Step 1: Extract TSX Metadata ==="
python3 step_7a_tsx_extractor.py Inputs/ui_react_component.tsx tsx_metadata.json application_config.json

echo ""
echo "=== Step 2: Create Wiring Plan ==="
python3 step_7b_frontend_wiring_claude_llm.py application_config.json tsx_metadata.json wired_ui.json

echo ""
echo "=== Step 3: Generate React App ==="
python3 step_7c_frontend_generator_claude_llm.py wired_ui.json Inputs/ui_react_component.tsx . ./output tsx_metadata.json

echo ""
echo "=========================================="
echo "Verification"
echo "=========================================="

# Check key files exist
echo "Checking generated files..."
if [ -f "output/src/schemas/Userstory1FormSchema.ts" ]; then
    echo "✓ Zod schema generated"
else
    echo "✗ Zod schema missing"
fi

if [ -f "output/src/hooks/useUserstory1Logic.ts" ]; then
    echo "✓ React Hook Form hook generated"
else
    echo "✗ Hook missing"
fi

if grep -q "react-hook-form" output/package.json; then
    echo "✓ React Hook Form dependency added"
else
    echo "✗ React Hook Form dependency missing"
fi

if grep -q "register(" output/src/NonSalableInventory_WIRED.tsx; then
    register_count=$(grep -c "register(" output/src/NonSalableInventory_WIRED.tsx)
    echo "✓ Form fields wired with register (found $register_count instances)"
else
    echo "✗ No register() found in TSX"
fi

if grep -q "handleSubmit" output/src/NonSalableInventory_WIRED.tsx; then
    echo "✓ handleSubmit() found in TSX"
else
    echo "✗ handleSubmit() missing"
fi

echo ""
echo "=========================================="
echo "SUCCESS! Pipeline completed."
echo "=========================================="
echo ""
echo "Next steps:"
echo "  1. cd output"
echo "  2. npm install"
echo "  3. npm start"
echo ""
echo "The React app will open at http://localhost:3000"
echo ""

