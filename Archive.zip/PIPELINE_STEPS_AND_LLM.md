# Pipeline Steps and LLM Usage

## Step order (see `run_all_steps.sh`)

| Step | Script | Output | Uses LLM? |
|------|--------|--------|-----------|
| 0 | `ensure_user_story_json.py` | `JSON/user_story_analysis_llm.json` | No |
| 1b | `step_1b_ui_component_analyzer_rag.py` | `JSON/ui_component_analysis*.json` | **Yes** |
| 1c | `step_1c_database_schema_analyzer.py` | `JSON/database_schema.json` | No |
| 2 | `step2.py` | `config_output/application_config.json` | No |
| 4 | `step_4_backend_code_generator_db_manager.py` (optional) | `Generated/backend/` | No |
| 7a | `step_7a_tsx_extractor.py` | `config_output/tsx_metadata.json` | No |
| 7b | `step_7b_frontend_wiring_claude_llm.py` | `config_output/wired_ui.json` | No (deterministic) |
| 7c | `step_7c_frontend_generator_claude_llm.py` | `frontend_output/` | No (deterministic) |

## Where LLM is used

**Only step 1b** uses an LLM:

- **Script:** `step_1b_ui_component_analyzer_rag.py`
- **Purpose:** “RAG-enhanced” UI component analysis: it takes the base parse of the React/TSX file and uses an LLM (Azure OpenAI or OpenAI via `step_1b_rag_enhanced_analyzer`) to add business context, screen detection, and richer structure.
- **Dependencies:** `openai`, optional Azure Key Vault; API key via `AZURE_OPENAI_API_KEY` or `.env`.
- **When API key is missing:** Step 1b falls back to the base (regex) analysis only; `screens` may stay empty, so step 7b adds a **fallback screen mapping** from config + `top_level_handlers` so RHF/Zod and service wiring still run in step 7c.

Steps 7a, 7b, and 7c are **deterministic** (no LLM): they use config, TSX metadata, and wiring rules only.

**Step 7c** applies **React Hook Form (RHF)** and **Zod** validation, and wires **service calls** (Axios):
- Generates a screen hook (`useUs1Logic.ts`) with `useForm`, `zodResolver(Us1FormSchema)`, and `NsiItemsService.create()` in the submit handler.
- Injects hook call inside the component (after first useState block); injects `showNotification` if missing.
- Wires form inputs to `register('fieldName')` and `formState.errors` (including camelCase/snake_case for `formData.vendorId` → `register('vendor_id')`).
- Adds `useEffect` to load initial data via `NsiItemsService.getAll()` (and optional InventoryService).
- Replaces handler bodies with `handleFormSubmit()` so “Add Item” runs Zod validation and then the API call.
