#!/usr/bin/env bash
#
# Run all pipeline steps in the correct order.
# Uses .venv if present; requires Python 3.
#
# Step order:
#   0. ensure_user_story_json.py     -> JSON/user_story_analysis_llm.json (if missing)
#   1b. step_1b_ui_component_analyzer_rag.py -> JSON/ui_component_analysis*.json
#   1c. step_1c_database_schema_analyzer.py  -> JSON/database_schema.json
#   2.  step2.py                     -> config_output/application_config.json
#   4.  step_4_backend_code_generator_db_manager.py (optional) -> Generated/backend
#   7a. step_7a_tsx_extractor.py     -> config_output/tsx_metadata.json
#   7b. step_7b_frontend_wiring_claude_llm.py -> config_output/wired_ui.json
#   7c. step_7c_frontend_generator_claude_llm.py -> frontend_output/
#
# Usage:
#   ./run_all_steps.sh              # Analysis + config + frontend (default)
#   ./run_all_steps.sh --with-backend   # Also run backend code generator (DB manager)
#   ./run_all_steps.sh --frontend-only  # Skip analysis/config; run only 7a, 7b, 7c
#

set -e
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_ROOT"

# Python: use .venv if present
if [ -d ".venv" ]; then
  PYTHON=".venv/bin/python"
  echo "[VENV] Using .venv"
else
  PYTHON="python3"
fi

WITH_BACKEND=false
FRONTEND_ONLY=false
for arg in "$@"; do
  case "$arg" in
    --with-backend)   WITH_BACKEND=true ;;
    --frontend-only)  FRONTEND_ONLY=true ;;
    -h|--help)
      echo "Usage: $0 [--with-backend] [--frontend-only]"
      echo "  --with-backend   Also run backend code generator (step_4_backend_code_generator_db_manager)"
      echo "  --frontend-only Skip analysis and config; run only frontend steps (7a, 7b, 7c)"
      exit 0
      ;;
  esac
done

echo "=============================================="
echo " Pipeline: Run All Steps (correct order)"
echo "=============================================="
echo "Project root: $PROJECT_ROOT"
echo ""

# Resolve TSX input once (used by 7a and 7c)
TSX_INPUT=""
[ -f "Inputs/NSIItemEnttry.tsx" ] && TSX_INPUT="Inputs/NSIItemEnttry.tsx"
[ -z "$TSX_INPUT" ] && TSX_INPUT="$(find Inputs -maxdepth 1 -name '*.tsx' 2>/dev/null | head -1)"

# --- 0. Ensure user story JSON exists (needed for step2) ---
if [ "$FRONTEND_ONLY" = false ]; then
  echo "[0] Ensuring user_story_analysis_llm.json..."
  $PYTHON ensure_user_story_json.py
  echo ""
fi

# --- Step 1b: UI component analyzer ---
if [ "$FRONTEND_ONLY" = false ]; then
  if [ ! -f "Inputs/NSIItemEnttry.tsx" ]; then
    echo "[SKIP] Step 1b: Inputs/NSIItemEnttry.tsx not found."
  else
    echo "[1b] Step 1b: UI component analyzer..."
    $PYTHON step_1b_ui_component_analyzer_rag.py -i Inputs/NSIItemEnttry.tsx -o JSON/ui_component_analysis.json
    echo ""
  fi
fi

# --- Step 1c: Database schema analyzer ---
if [ "$FRONTEND_ONLY" = false ]; then
  if [ ! -f "Inputs/Refined Database Schema.txt" ]; then
    echo "[SKIP] Step 1c: Inputs/Refined Database Schema.txt not found."
  else
    echo "[1c] Step 1c: Database schema analyzer..."
    $PYTHON step_1c_database_schema_analyzer.py -i "Inputs/Refined Database Schema.txt" -o JSON/database_schema.json
    echo ""
  fi
fi

# --- Step 2: Application config generator ---
if [ "$FRONTEND_ONLY" = false ]; then
  if [ ! -f "JSON/user_story_analysis_llm.json" ] || [ ! -f "JSON/ui_component_analysis_llm.json" ] || [ ! -f "JSON/database_schema.json" ]; then
    echo "[SKIP] Step 2: Missing JSON inputs (user_story, ui_component, database_schema)."
  else
    echo "[2] Step 2: Application config generator..."
    mkdir -p config_output
    $PYTHON step2.py -u JSON/user_story_analysis_llm.json -i JSON/ui_component_analysis_llm.json -d JSON/database_schema.json -o config_output
    echo ""
  fi
fi

# --- Step 4 (optional): Backend code generator (DB manager) ---
if [ "$WITH_BACKEND" = true ]; then
  if [ ! -f "config_output/application_config.json" ]; then
    echo "[SKIP] Step 4: config_output/application_config.json not found. Run without --frontend-only first."
  else
    echo "[4] Step 4: Backend code generator (DB manager)..."
    mkdir -p Generated
    $PYTHON step_4_backend_code_generator_db_manager.py -i config_output/application_config.json -o Generated/backend
    echo ""
  fi
fi

# --- Step 7a: TSX extractor ---
if [ ! -f "config_output/application_config.json" ]; then
  echo "[SKIP] Step 7a: config_output/application_config.json not found."
elif [ -z "$TSX_INPUT" ] || [ ! -f "$TSX_INPUT" ]; then
  echo "[SKIP] Step 7a: No TSX file found in Inputs/."
else
  echo "[7a] Step 7a: TSX extractor..."
  $PYTHON step_7a_tsx_extractor.py "$TSX_INPUT" config_output/tsx_metadata.json config_output/application_config.json
  echo ""
fi

# --- Step 7b: Frontend wiring ---
if [ ! -f "config_output/application_config.json" ] || [ ! -f "config_output/tsx_metadata.json" ]; then
  echo "[SKIP] Step 7b: Missing config_output/application_config.json or tsx_metadata.json."
else
  echo "[7b] Step 7b: Frontend wiring..."
  $PYTHON step_7b_frontend_wiring_claude_llm.py config_output/application_config.json config_output/tsx_metadata.json config_output/wired_ui.json
  echo ""
fi

# --- Step 7c: Frontend code generator ---
if [ ! -f "config_output/wired_ui.json" ]; then
  echo "[SKIP] Step 7c: config_output/wired_ui.json not found."
elif [ -z "$TSX_INPUT" ] || [ ! -f "$TSX_INPUT" ]; then
  echo "[SKIP] Step 7c: No TSX file in Inputs/."
else
  echo "[7c] Step 7c: Frontend code generator..."
  $PYTHON step_7c_frontend_generator_claude_llm.py config_output/wired_ui.json "$TSX_INPUT" Inputs frontend_output config_output/tsx_metadata.json
  echo ""
  # Optional: validate frontend build (install deps and build)
  if [ -d "frontend_output" ] && [ -f "frontend_output/package.json" ]; then
    echo "[7c-validate] Installing dependencies and building frontend..."
    (cd frontend_output && npm install --silent 2>/dev/null && npm run build 2>&1) && echo "[7c-validate] Build succeeded." || echo "[7c-validate] Build failed; check frontend_output for errors."
    echo ""
  fi
fi

echo "=============================================="
echo " Pipeline finished."
echo "=============================================="
echo "Outputs:"
echo "  - config_output/application_config.json, wired_ui.json, tsx_metadata.json"
echo "  - frontend_output/  (React app; run: cd frontend_output && npm install && npm start)"
if [ "$WITH_BACKEND" = true ]; then
  echo "  - Generated/backend/  (Backend code)"
fi
echo ""
