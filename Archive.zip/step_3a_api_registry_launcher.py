#!/usr/bin/env python3
"""
API Registry Launcher
====================

Interactive launcher for the API Registry Management System.
"""

import subprocess
import sys

def show_main_menu():
    """Show main menu options"""
    while True:
        print("\n" + "="*60)
        print("API REGISTRY MANAGEMENT SYSTEM")
        print("="*60)
        print("1. Process APIs from configuration file")
        print("2. Review pending approval requests")
        print("3. Show registry statistics")
        print("4. Exit")
        print("-"*60)
        
        try:
            choice = int(input("Enter your choice (1-4): "))
            
            if choice == 1:
                config_file = input("Enter config file path (or press Enter for default): ").strip()
                if not config_file:
                    config_file = "config_output/application_config.json"
                
                cmd = ["python3", "step_3b_api_registry_manager.py", "--config", config_file]
                subprocess.run(cmd)
                
            elif choice == 2:
                cmd = ["python3", "step_3b_api_registry_manager.py", "--review-only"]
                subprocess.run(cmd)
                
            elif choice == 3:
                cmd = ["python3", "step_3b_api_registry_manager.py", "--stats-only"]
                subprocess.run(cmd)
                
            elif choice == 4:
                print("Goodbye!")
                sys.exit(0)
                
            else:
                print("Please enter a valid choice (1-4)")
                
        except ValueError:
            print("Please enter a valid number")
        except KeyboardInterrupt:
            print("\nGoodbye!")
            sys.exit(0)

if __name__ == "__main__":
    show_main_menu()
